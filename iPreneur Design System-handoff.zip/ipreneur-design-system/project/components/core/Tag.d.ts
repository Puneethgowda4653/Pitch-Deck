import React from "react";

export interface TagProps extends React.HTMLAttributes<HTMLSpanElement> {
  /** @default "neutral" */
  tone?: "neutral" | "brand";
  /** Render a removable "×" and fire this on click. */
  onRemove?: () => void;
  icon?: React.ReactNode;
  children?: React.ReactNode;
}

/** Square-ish input chip — keywords, filters, removable selections. */
export function Tag(props: TagProps): JSX.Element;
