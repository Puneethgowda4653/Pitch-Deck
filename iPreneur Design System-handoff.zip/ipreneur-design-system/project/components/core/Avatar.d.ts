import React from "react";

export interface AvatarProps extends React.HTMLAttributes<HTMLSpanElement> {
  /** Used for the initials fallback and image alt. */
  name?: string;
  /** Image URL; falls back to gradient initials when absent. */
  src?: string;
  /** @default "md" */
  size?: "sm" | "md" | "lg";
  /** Rounded-square instead of circle (good for company logos). */
  square?: boolean;
}

/** Circular avatar — image or gradient initials fallback. */
export function Avatar(props: AvatarProps): JSX.Element;
