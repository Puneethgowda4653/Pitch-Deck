import React from "react";

export interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  /** Visual style. `primary` = gradient CTA with glow. */
  variant?: "primary" | "solid" | "secondary" | "ghost" | "danger";
  /** Control height. @default "md" */
  size?: "sm" | "md" | "lg";
  /** Leading icon node (e.g. a lucide icon). */
  icon?: React.ReactNode;
  /** Trailing icon node. */
  iconRight?: React.ReactNode;
  /** Show a spinner and disable interaction. */
  loading?: boolean;
  /** Stretch to container width. */
  fullWidth?: boolean;
  /** Render as another element (e.g. "a"). @default "button" */
  as?: "button" | "a";
  children?: React.ReactNode;
}

/**
 * Primary action control for iPreneur. Gradient `primary` for the single
 * key action on a view; `secondary` for the common neutral button.
 *
 * @startingPoint section="Core" subtitle="Buttons — gradient, secondary, ghost, danger" viewport="700x160"
 */
export function Button(props: ButtonProps): JSX.Element;
