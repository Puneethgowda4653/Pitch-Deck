Action control for iPreneur — gradient `primary` for the one key action per view, `secondary` for neutral actions.

```jsx
<Button variant="primary" icon={<Plus size={16} />}>New Deck</Button>
<Button variant="secondary">Cancel</Button>
<Button variant="ghost" size="sm">Skip</Button>
<Button variant="danger">Delete</Button>
<Button variant="primary" loading>Generating…</Button>
```

Variants: `primary` (blue→violet gradient + glow), `solid` (flat violet), `secondary` (white w/ border), `ghost` (transparent), `danger`. Sizes `sm | md | lg`. Props: `icon`, `iconRight`, `loading`, `fullWidth`, `as="a"`.
