import React from "react";

const CSS = `
.ipr-tag{
  display:inline-flex; align-items:center; gap:6px;
  font-family:var(--font-body); font-size:var(--text-xs); font-weight:var(--weight-medium);
  line-height:1; padding:6px 10px; border-radius:var(--radius-sm);
  background:var(--surface-sunken); color:var(--text-body);
  border:1px solid var(--border-subtle);
}
.ipr-tag--brand{ background:var(--violet-50); color:var(--violet-700); border-color:var(--violet-200); }
.ipr-tag__x{ display:inline-flex; cursor:pointer; opacity:.55; margin-right:-2px;
  border:0; background:none; padding:0; color:inherit; font-size:13px; line-height:1; }
.ipr-tag__x:hover{ opacity:1; }
`;

function useStyle() {
  React.useEffect(() => {
    if (document.getElementById("ipr-tag-css")) return;
    const s = document.createElement("style");
    s.id = "ipr-tag-css"; s.textContent = CSS;
    document.head.appendChild(s);
  }, []);
}

/** Input-style chip — keywords, filters, removable selections. */
export function Tag({ tone = "neutral", onRemove, icon, className = "", children, ...props }) {
  useStyle();
  const cls = ["ipr-tag", tone === "brand" ? "ipr-tag--brand" : "", className].filter(Boolean).join(" ");
  return (
    <span className={cls} {...props}>
      {icon ? <span style={{ display: "inline-flex" }} aria-hidden="true">{icon}</span> : null}
      {children}
      {onRemove ? <button type="button" className="ipr-tag__x" onClick={onRemove} aria-label="Remove">×</button> : null}
    </span>
  );
}
