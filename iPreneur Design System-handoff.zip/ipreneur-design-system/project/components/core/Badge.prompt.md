Compact pill label for status & categories — pitch deck status, funding stage, industry tags.

```jsx
<Badge tone="success" dot>Ready</Badge>
<Badge tone="warning" dot>Generating</Badge>
<Badge tone="brand">Seed</Badge>
<Badge tone="solid">Pro</Badge>
```

Tones: `brand | neutral | success | warning | danger | info | solid`. Props: `dot`, `icon`.
