import React from "react";

const CSS = `
.ipr-card{
  background:var(--surface-card); border:1px solid var(--border-subtle);
  border-radius:var(--radius-lg); box-shadow:var(--shadow-sm);
  transition:transform var(--dur-base) var(--ease-out), box-shadow var(--dur-base) var(--ease-out), border-color var(--dur-base) var(--ease-out);
}
.ipr-card--pad{ padding:var(--space-6); }
.ipr-card--pad-sm{ padding:var(--space-4); }
.ipr-card--interactive{ cursor:pointer; }
.ipr-card--interactive:hover{ transform:translateY(-2px); box-shadow:var(--shadow-lg); border-color:var(--border-brand); }
.ipr-card--gradient{ position:relative; overflow:hidden; }
.ipr-card--gradient::before{ content:""; position:absolute; inset:0;
  background:var(--grad-brand-soft); opacity:.7; pointer-events:none; }
.ipr-card--gradient > *{ position:relative; }
.ipr-card--accent{ border-top:3px solid transparent; border-image:var(--grad-brand) 1; }
`;

function useStyle() {
  React.useEffect(() => {
    if (document.getElementById("ipr-card-css")) return;
    const s = document.createElement("style");
    s.id = "ipr-card-css"; s.textContent = CSS;
    document.head.appendChild(s);
  }, []);
}

/** Surface container for grouping content. */
export function Card({
  padding = "md",
  interactive = false,
  gradient = false,
  className = "",
  style,
  children,
  ...props
}) {
  useStyle();
  const cls = [
    "ipr-card",
    padding === "md" ? "ipr-card--pad" : padding === "sm" ? "ipr-card--pad-sm" : "",
    interactive ? "ipr-card--interactive" : "",
    gradient ? "ipr-card--gradient" : "",
    className,
  ].filter(Boolean).join(" ");
  return (
    <div className={cls} style={style} {...props}>{children}</div>
  );
}
