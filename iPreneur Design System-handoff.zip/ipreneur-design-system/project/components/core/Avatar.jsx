import React from "react";

const CSS = `
.ipr-avatar{
  display:inline-flex; align-items:center; justify-content:center;
  font-family:var(--font-display); font-weight:var(--weight-bold);
  color:var(--text-on-brand); background:var(--grad-brand);
  border-radius:50%; overflow:hidden; flex-shrink:0; line-height:1;
  box-shadow:inset 0 0 0 1px rgba(255,255,255,.18);
}
.ipr-avatar img{ width:100%; height:100%; object-fit:cover; }
.ipr-avatar--sm{ width:28px; height:28px; font-size:11px; }
.ipr-avatar--md{ width:38px; height:38px; font-size:14px; }
.ipr-avatar--lg{ width:52px; height:52px; font-size:18px; }
.ipr-avatar--square{ border-radius:var(--radius-md); }
`;

function useStyle() {
  React.useEffect(() => {
    if (document.getElementById("ipr-avatar-css")) return;
    const s = document.createElement("style");
    s.id = "ipr-avatar-css"; s.textContent = CSS;
    document.head.appendChild(s);
  }, []);
}

function initials(name = "") {
  const parts = name.trim().split(/\s+/).filter(Boolean);
  if (!parts.length) return "?";
  return (parts[0][0] + (parts[1]?.[0] ?? "")).toUpperCase();
}

/** Circular user/company avatar — image or gradient initials fallback. */
export function Avatar({ name = "", src, size = "md", square = false, className = "", style, ...props }) {
  useStyle();
  const cls = [
    "ipr-avatar",
    `ipr-avatar--${size}`,
    square ? "ipr-avatar--square" : "",
    className,
  ].filter(Boolean).join(" ");
  return (
    <span className={cls} style={style} {...props}>
      {src ? <img src={src} alt={name} /> : initials(name)}
    </span>
  );
}
