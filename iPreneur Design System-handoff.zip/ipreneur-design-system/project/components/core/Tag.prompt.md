Input-style chip for keywords, filters, and removable selections (lower-emphasis than Badge).

```jsx
<Tag>Fintech</Tag>
<Tag tone="brand">SaaS</Tag>
<Tag onRemove={() => drop(id)}>Remote</Tag>
```

Props: `tone` (`neutral|brand`), `onRemove` (adds ×), `icon`.
