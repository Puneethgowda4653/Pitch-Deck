Circular user/company avatar — shows an image, or gradient initials when no `src`.

```jsx
<Avatar name="Aanya Rao" />
<Avatar name="Stripe" src="/logo.png" size="lg" square />
```

Props: `name`, `src`, `size` (`sm|md|lg`), `square`.
