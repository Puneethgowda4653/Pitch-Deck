Surface container — white card, soft purple-tinted shadow, 16px radius. The default content surface.

```jsx
<Card>Plain content</Card>
<Card interactive onClick={open}>Lifts + brand border on hover</Card>
<Card gradient padding="sm">Soft blue→violet wash</Card>
```

Props: `padding` (`none|sm|md`), `interactive` (hover lift), `gradient` (soft wash).
