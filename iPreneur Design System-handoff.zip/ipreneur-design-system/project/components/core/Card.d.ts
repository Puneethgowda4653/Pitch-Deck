import React from "react";

export interface CardProps extends React.HTMLAttributes<HTMLDivElement> {
  /** Internal padding. Use "none" to lay out your own. @default "md" */
  padding?: "none" | "sm" | "md";
  /** Lift + brand border on hover. */
  interactive?: boolean;
  /** Soft blue→violet wash background. */
  gradient?: boolean;
  children?: React.ReactNode;
}

/**
 * Surface container — white, soft purple-tinted shadow, 16px radius.
 * The default content card across the iPreneur app.
 *
 * @startingPoint section="Core" subtitle="Card surface — plain, interactive, gradient" viewport="700x200"
 */
export function Card(props: CardProps): JSX.Element;
