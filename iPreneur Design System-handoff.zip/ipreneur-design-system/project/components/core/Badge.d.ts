import React from "react";

export interface BadgeProps extends React.HTMLAttributes<HTMLSpanElement> {
  /** Semantic color. @default "brand" */
  tone?: "brand" | "neutral" | "success" | "warning" | "danger" | "info" | "solid";
  /** Leading status dot. */
  dot?: boolean;
  /** Leading icon node. */
  icon?: React.ReactNode;
  children?: React.ReactNode;
}

/**
 * Compact pill label for status and categories (Draft, Ready, Seed, etc).
 *
 * @startingPoint section="Core" subtitle="Badges — all semantic tones" viewport="700x120"
 */
export function Badge(props: BadgeProps): JSX.Element;
