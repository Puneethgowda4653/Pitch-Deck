import React from "react";

export interface TabItem {
  value: string;
  label: string;
  icon?: React.ReactNode;
  /** Optional count pill (e.g. number of items). */
  count?: number;
}

export interface TabsProps extends Omit<React.HTMLAttributes<HTMLDivElement>, "onChange"> {
  /** Tabs as strings or {value,label,icon,count}. */
  tabs?: Array<string | TabItem>;
  /** Currently selected value (controlled). */
  value?: string;
  /** Fired with the next tab value. */
  onChange?: (value: string) => void;
  /** Stretch tabs to fill the container. */
  fullWidth?: boolean;
}

/**
 * Segmented control / tab switcher — All / Ready / Drafts filters, view toggles.
 *
 * @startingPoint section="Data" subtitle="Segmented tabs with counts" viewport="700x110"
 */
export function Tabs(props: TabsProps): JSX.Element;
