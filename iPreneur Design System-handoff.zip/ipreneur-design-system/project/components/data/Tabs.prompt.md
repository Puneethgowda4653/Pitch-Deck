Segmented tab switcher (controlled) — All / Ready / Drafts filters, view toggles.

```jsx
const [tab, setTab] = useState("all");
<Tabs
  value={tab}
  onChange={setTab}
  tabs={[
    { value: "all", label: "All", count: 12 },
    { value: "ready", label: "Ready", count: 7 },
    { value: "drafts", label: "Drafts", count: 5 },
  ]}
/>
```

Props: `tabs` (string[] or {value,label,icon,count}[]), `value`, `onChange`, `fullWidth`.
