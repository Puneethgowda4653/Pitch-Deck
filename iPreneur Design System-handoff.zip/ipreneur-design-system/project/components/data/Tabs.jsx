import React from "react";

const CSS = `
.ipr-tabs{ display:inline-flex; gap:4px; padding:4px; background:var(--surface-sunken);
  border:1px solid var(--border-subtle); border-radius:var(--radius-md); }
.ipr-tabs--full{ display:flex; width:100%; }
.ipr-tabs--full .ipr-tab{ flex:1; justify-content:center; }
.ipr-tab{
  display:inline-flex; align-items:center; gap:7px; border:0; cursor:pointer;
  font-family:var(--font-body); font-size:var(--text-sm); font-weight:var(--weight-semibold);
  color:var(--text-muted); background:transparent; padding:8px 15px;
  border-radius:var(--radius-sm); white-space:nowrap;
  transition:color var(--dur-base) var(--ease-out), background var(--dur-base) var(--ease-out), box-shadow var(--dur-base) var(--ease-out);
}
.ipr-tab:hover{ color:var(--text-strong); }
.ipr-tab--active{ color:var(--text-brand); background:var(--surface-card); box-shadow:var(--shadow-sm); }
.ipr-tab__count{ font-family:var(--font-mono); font-size:11px; padding:1px 7px;
  border-radius:var(--radius-pill); background:var(--violet-100); color:var(--violet-700); }
.ipr-tab--active .ipr-tab__count{ background:var(--violet-200); }
`;

function useStyle() {
  React.useEffect(() => {
    if (document.getElementById("ipr-tabs-css")) return;
    const s = document.createElement("style");
    s.id = "ipr-tabs-css"; s.textContent = CSS;
    document.head.appendChild(s);
  }, []);
}

/** Segmented tab switcher (controlled). */
export function Tabs({ tabs = [], value, onChange, fullWidth = false, className = "", ...props }) {
  useStyle();
  const cls = ["ipr-tabs", fullWidth ? "ipr-tabs--full" : "", className].filter(Boolean).join(" ");
  return (
    <div className={cls} role="tablist" {...props}>
      {tabs.map((t) => {
        const tab = typeof t === "string" ? { value: t, label: t } : t;
        const active = tab.value === value;
        return (
          <button key={tab.value} type="button" role="tab" aria-selected={active}
            className={"ipr-tab" + (active ? " ipr-tab--active" : "")}
            onClick={() => onChange && onChange(tab.value)}>
            {tab.icon ? <span style={{ display: "inline-flex" }} aria-hidden="true">{tab.icon}</span> : null}
            {tab.label}
            {tab.count != null ? <span className="ipr-tab__count">{tab.count}</span> : null}
          </button>
        );
      })}
    </div>
  );
}
