import React from "react";

export interface StatCardProps extends React.HTMLAttributes<HTMLDivElement> {
  /** Leading icon node. */
  icon?: React.ReactNode;
  /** Primary metric (e.g. "12", "$1.2M"). */
  value?: React.ReactNode;
  /** Caption under the value. */
  label?: string;
  /** Optional trend chip appended to the label. */
  delta?: { text: string; dir?: "up" | "down" };
  /** Fill the icon tile with the brand gradient. */
  gradientIcon?: boolean;
}

/**
 * Compact metric tile for dashboards — total decks, ready, in-progress.
 *
 * @startingPoint section="Data" subtitle="Stat tile — icon, value, label, delta" viewport="700x130"
 */
export function StatCard(props: StatCardProps): JSX.Element;
