Gradient progress bar — deck-generation steps, usage meters, plan limits.

```jsx
<ProgressBar value={68} label="Overall progress" showValue />
<ProgressBar value={40} animated size="lg" />
```

Props: `value` (0–100), `label`, `showValue`, `size` (`sm|md|lg`), `animated` (striped barber-pole).
