Compact metric tile for dashboards — total decks, ready count, MRR, etc.

```jsx
<StatCard icon={<FileText size={18} />} value="12" label="Total decks" />
<StatCard gradientIcon icon={<TrendingUp size={18} />} value="$1.2M" label="Tracked ARR" delta={{ text: "+8%", dir: "up" }} />
```

Props: `icon`, `value`, `label`, `delta` ({text, dir}), `gradientIcon`.
