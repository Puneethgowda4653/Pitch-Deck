import React from "react";

export interface ProgressBarProps extends React.HTMLAttributes<HTMLDivElement> {
  /** 0–100. */
  value?: number;
  /** Caption shown top-left. */
  label?: string;
  /** Show the rounded percentage top-right (mono). */
  showValue?: boolean;
  /** Track thickness. @default "md" */
  size?: "sm" | "md" | "lg";
  /** Animated barber-pole stripe for in-progress jobs. */
  animated?: boolean;
}

/**
 * Gradient progress bar — deck-generation steps, usage meters, plan limits.
 *
 * @startingPoint section="Data" subtitle="Progress bar — label, %, animated" viewport="700x140"
 */
export function ProgressBar(props: ProgressBarProps): JSX.Element;
