import React from "react";

export interface SwitchProps {
  /** Controlled on/off state. */
  checked?: boolean;
  /** Fired with the next boolean value. */
  onChange?: (checked: boolean, e: React.ChangeEvent<HTMLInputElement>) => void;
  /** Inline trailing label. */
  label?: string;
  disabled?: boolean;
  className?: string;
}

/** Gradient toggle switch for binary settings ("Generate immediately"). */
export function Switch(props: SwitchProps): JSX.Element;
