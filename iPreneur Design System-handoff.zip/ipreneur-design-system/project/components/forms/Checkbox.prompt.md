Checkbox with a gradient checked fill and animated tick.

```jsx
<Checkbox checked={agree} onChange={setAgree} label="I agree to the terms" />
```

Props: `checked`, `onChange(checked, e)`, `label`, `disabled`.
