import React from "react";

const CSS = `
.ipr-check{ display:inline-flex; align-items:flex-start; gap:10px; cursor:pointer; user-select:none; }
.ipr-check--disabled{ opacity:.5; cursor:not-allowed; }
.ipr-check__box{
  width:20px; height:20px; border-radius:6px; flex-shrink:0; margin-top:1px;
  border:1.5px solid var(--border-strong); background:var(--surface-card);
  display:inline-flex; align-items:center; justify-content:center; color:#fff;
  transition:background var(--dur-fast) var(--ease-out), border-color var(--dur-fast) var(--ease-out);
}
.ipr-check__box--on{ background:var(--grad-brand); border-color:transparent; }
.ipr-check__box svg{ opacity:0; transform:scale(.6); transition:all var(--dur-fast) var(--ease-out); }
.ipr-check__box--on svg{ opacity:1; transform:scale(1); }
.ipr-check input{ position:absolute; opacity:0; width:0; height:0; }
.ipr-check:focus-within .ipr-check__box{ box-shadow:var(--focus-ring); }
.ipr-check__label{ font-family:var(--font-body); font-size:var(--text-sm); color:var(--text-body); line-height:1.4; }
`;

function useStyle() {
  React.useEffect(() => {
    if (document.getElementById("ipr-check-css")) return;
    const s = document.createElement("style");
    s.id = "ipr-check-css"; s.textContent = CSS;
    document.head.appendChild(s);
  }, []);
}

/** Checkbox with gradient checked state. */
export function Checkbox({ checked = false, onChange, label, disabled = false, className = "", ...props }) {
  useStyle();
  const cls = ["ipr-check", disabled ? "ipr-check--disabled" : "", className].filter(Boolean).join(" ");
  return (
    <label className={cls}>
      <span className={"ipr-check__box" + (checked ? " ipr-check__box--on" : "")}>
        <input type="checkbox" checked={checked} disabled={disabled}
          onChange={(e) => onChange && onChange(e.target.checked, e)} {...props} />
        <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3.4" strokeLinecap="round" strokeLinejoin="round"><polyline points="20 6 9 17 4 12" /></svg>
      </span>
      {label ? <span className="ipr-check__label">{label}</span> : null}
    </label>
  );
}
