Gradient toggle for binary settings — the track fills with the brand gradient when on.

```jsx
<Switch checked={auto} onChange={setAuto} label="Generate immediately" />
```

Props: `checked`, `onChange(checked, e)`, `label`, `disabled`.
