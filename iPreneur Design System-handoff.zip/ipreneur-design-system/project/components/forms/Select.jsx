import React from "react";

const CSS = `
.ipr-select-field{ display:flex; flex-direction:column; gap:7px; }
.ipr-select-field__label{ font-family:var(--font-body); font-size:var(--text-sm);
  font-weight:var(--weight-semibold); color:var(--text-strong); }
.ipr-select-wrap{ position:relative; display:flex; align-items:center; }
.ipr-select{
  width:100%; height:44px; padding:0 38px 0 14px; font-family:var(--font-body);
  font-size:var(--text-sm); color:var(--text-strong); cursor:pointer;
  background:var(--surface-card); border:1px solid var(--border-default);
  border-radius:var(--radius-md); outline:none; appearance:none;
  transition:border-color var(--dur-base) var(--ease-out), box-shadow var(--dur-base) var(--ease-out);
}
.ipr-select:hover{ border-color:var(--border-strong); }
.ipr-select:focus{ border-color:var(--brand); box-shadow:var(--focus-ring); }
.ipr-select:disabled{ background:var(--surface-sunken); color:var(--text-faint); cursor:not-allowed; }
.ipr-select--placeholder{ color:var(--text-faint); }
.ipr-select-wrap__chev{ position:absolute; right:13px; pointer-events:none;
  color:var(--text-muted); display:inline-flex; }
`;

function useStyle() {
  React.useEffect(() => {
    if (document.getElementById("ipr-select-css")) return;
    const s = document.createElement("style");
    s.id = "ipr-select-css"; s.textContent = CSS;
    document.head.appendChild(s);
  }, []);
}

/** Native select, styled to match Input. */
export function Select({
  label, options = [], placeholder, id, value, className = "", style, ...props
}) {
  useStyle();
  const autoId = React.useId();
  const fieldId = id || autoId;
  const isPlaceholder = (value === "" || value == null) && placeholder;
  const cls = ["ipr-select", isPlaceholder ? "ipr-select--placeholder" : "", className].filter(Boolean).join(" ");
  return (
    <div className="ipr-select-field" style={style}>
      {label ? <label className="ipr-select-field__label" htmlFor={fieldId}>{label}</label> : null}
      <div className="ipr-select-wrap">
        <select id={fieldId} className={cls} value={value} {...props}>
          {placeholder ? <option value="">{placeholder}</option> : null}
          {options.map((o) => {
            const opt = typeof o === "string" ? { value: o, label: o } : o;
            return <option key={opt.value} value={opt.value}>{opt.label}</option>;
          })}
        </select>
        <span className="ipr-select-wrap__chev" aria-hidden="true">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round"><polyline points="6 9 12 15 18 9" /></svg>
        </span>
      </div>
    </div>
  );
}
