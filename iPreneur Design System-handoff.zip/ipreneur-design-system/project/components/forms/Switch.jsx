import React from "react";

const CSS = `
.ipr-switch{ display:inline-flex; align-items:center; gap:11px; cursor:pointer; user-select:none; }
.ipr-switch--disabled{ opacity:.5; cursor:not-allowed; }
.ipr-switch__track{
  position:relative; width:44px; height:26px; border-radius:var(--radius-pill);
  background:var(--neutral-300); transition:background var(--dur-base) var(--ease-out);
  flex-shrink:0;
}
.ipr-switch__track--on{ background:var(--grad-brand); }
.ipr-switch__thumb{
  position:absolute; top:3px; left:3px; width:20px; height:20px; border-radius:50%;
  background:#fff; box-shadow:var(--shadow-sm);
  transition:transform var(--dur-base) var(--ease-out);
}
.ipr-switch__track--on .ipr-switch__thumb{ transform:translateX(18px); }
.ipr-switch input{ position:absolute; opacity:0; width:0; height:0; }
.ipr-switch__label{ font-family:var(--font-body); font-size:var(--text-sm); color:var(--text-body); }
.ipr-switch:focus-within .ipr-switch__track{ box-shadow:var(--focus-ring); }
`;

function useStyle() {
  React.useEffect(() => {
    if (document.getElementById("ipr-switch-css")) return;
    const s = document.createElement("style");
    s.id = "ipr-switch-css"; s.textContent = CSS;
    document.head.appendChild(s);
  }, []);
}

/** Toggle switch for binary settings. */
export function Switch({ checked = false, onChange, label, disabled = false, className = "", ...props }) {
  useStyle();
  const cls = ["ipr-switch", disabled ? "ipr-switch--disabled" : "", className].filter(Boolean).join(" ");
  return (
    <label className={cls}>
      <span className={"ipr-switch__track" + (checked ? " ipr-switch__track--on" : "")}>
        <input type="checkbox" checked={checked} disabled={disabled}
          onChange={(e) => onChange && onChange(e.target.checked, e)} {...props} />
        <span className="ipr-switch__thumb" />
      </span>
      {label ? <span className="ipr-switch__label">{label}</span> : null}
    </label>
  );
}
