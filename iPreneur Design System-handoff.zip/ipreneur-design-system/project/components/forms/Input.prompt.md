Text field with label, optional leading icon, hint, and error. 44px tall, focus ring in brand violet.

```jsx
<Input label="Company website" icon={<Globe size={16} />} placeholder="https://yourcompany.com" />
<Input label="Project name" error="Name is required" />
<Input label="Notes" multiline rows={5} />
```

Props: `label`, `hint`, `error`, `icon`, `multiline`, `rows` + native input attrs.
