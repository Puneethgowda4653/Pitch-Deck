import React from "react";

export interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  /** Field label rendered above the control. */
  label?: string;
  /** Helper text below the control. */
  hint?: string;
  /** Error message — turns the border red and replaces the hint. */
  error?: string;
  /** Leading icon node (single-line only). */
  icon?: React.ReactNode;
  /** Render a multiline <textarea>. */
  multiline?: boolean;
  /** Rows when multiline. @default 4 */
  rows?: number;
}

/**
 * Text input with label, leading icon, hint and error states.
 * Also renders a textarea via `multiline`.
 *
 * @startingPoint section="Forms" subtitle="Text input — label, icon, error" viewport="700x200"
 */
export function Input(props: InputProps): JSX.Element;
