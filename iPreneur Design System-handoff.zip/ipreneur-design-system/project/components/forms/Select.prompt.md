Native select styled to match Input — funding stage, business model, industry pickers.

```jsx
<Select
  label="Funding stage"
  placeholder="Select stage"
  options={["Pre-seed", "Seed", "Series A", "Series B"]}
  value={stage}
  onChange={e => setStage(e.target.value)}
/>
```

Props: `label`, `options` (string[] or {value,label}[]), `placeholder` + native select attrs.
