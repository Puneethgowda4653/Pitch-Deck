import React from "react";

export interface SelectOption { value: string; label: string; }

export interface SelectProps extends React.SelectHTMLAttributes<HTMLSelectElement> {
  /** Field label rendered above the control. */
  label?: string;
  /** Options as strings or {value,label} objects. */
  options?: Array<string | SelectOption>;
  /** Placeholder option (empty value, shown when nothing selected). */
  placeholder?: string;
}

/** Native select styled to match Input — funding stage, business model, etc. */
export function Select(props: SelectProps): JSX.Element;
