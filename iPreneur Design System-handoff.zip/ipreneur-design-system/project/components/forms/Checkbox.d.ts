import React from "react";

export interface CheckboxProps {
  checked?: boolean;
  onChange?: (checked: boolean, e: React.ChangeEvent<HTMLInputElement>) => void;
  /** Inline trailing label. */
  label?: string;
  disabled?: boolean;
  className?: string;
}

/** Checkbox with gradient checked state + animated tick. */
export function Checkbox(props: CheckboxProps): JSX.Element;
