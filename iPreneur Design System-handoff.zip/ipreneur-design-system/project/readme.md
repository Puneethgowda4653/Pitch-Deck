# iPreneur Design System

A light, professional **purple** design system for **iPreneur** — an AI-powered pitch-deck generator operated by a startup accelerator. iPreneur takes a company URL, crawls the site, researches the market, and generates an investor-ready pitch deck (PPTX/PDF) in minutes.

This system is intentionally **light and airy** — purple and its lighter shades, never a dark/obsidian theme. It's built to feel trustworthy and broadly appealing to founders across every industry and stage.

> **Design note.** The attached production codebase (`frontend/`) ships a *dark* obsidian-purple theme. The brand owner asked for a **light purple** redesign that "attracts all the categories." This system delivers that light direction while preserving the original product structure, copy, component vocabulary, and brand gradient. The two UI kits are the light reimagining of the real screens.

---

## Sources

- **Codebase:** `frontend/` — React 18 + Vite + TypeScript + TailwindCSS, lucide-react icons, framer-motion, @tanstack/react-query, react-hook-form + zod, recharts. Key screens read: `LandingPage.tsx`, `pages/dashboard/DashboardPage.tsx`, `pages/workspace/{NewProjectPage,WorkspacePage}.tsx`, `pages/auth/LoginPage.tsx`, `components/ui/Button.tsx`, `components/dashboard/{ProjectCard,StatsBar}.tsx`, `components/shared/StatusBadge.tsx`, `components/layout/DashboardLayout.tsx`, `components/workspace/AnalysisProgress.tsx`, `constants/index.ts`.
- **Logo:** `uploads/Ipreneur-color-logo-300x114.webp` → copied to `assets/ipreneur-logo.webp`. Wordmark "IPRENEUR" in a blue→violet→magenta gradient with a stacked-chevron mark and "Startup Accelerator" subline.

The original palette (from `tailwind.config.js`) anchored the brand colors: electric blue `#2540B5` and violet `#7B2CBF` as the gradient endpoints. Those endpoints are retained; everything around them was lifted into the light range.

---

## Content Fundamentals

**Voice:** confident, plain-spoken, founder-to-founder. Sells *speed* and *credibility*. Never hypey or jargon-heavy.

- **Person:** second person ("**your** idea", "**your** market"). The product refers to itself as "iPreneur" or "our AI."
- **Casing:** Sentence case everywhere — headings, buttons, labels, nav. *Not* Title Case. (e.g. "New Deck", "Create your pitch deck", "Generate immediately").
- **Verbs:** action-led, present tense — "Generate your deck", "Drop in a company URL", "Export PPTX".
- **Numbers & specificity:** concrete proof points — "in under five minutes", "~2 minutes", "12,000+ decks", "10-slide deck". Money & metrics in mono.
- **Length:** short. Headlines ≤ 8 words; subcopy one or two sentences. Microcopy reassures ("Analysis takes ~2 minutes · PPTX output · Fully editable").
- **Emoji:** none. The brand expresses warmth through color and the gradient, not emoji.
- **Example copy (from product):**
  - H1: "Turn your idea into an investor-ready pitch deck"
  - Sub: "iPreneur crawls your company website, researches your market, and generates a professional pitch deck tailored for investors — in under 5 minutes."
  - Empty state: "Drop in a company URL and watch AI generate an investor-ready deck in minutes."
  - Status verbs: Draft · Analyzing · Researching · Generating · Ready.

---

## Visual Foundations

**Color.** Light surfaces, purple accent. The page is `--surface-page` (#FAF8FE, a barely-there lavender); cards are pure white. The hero accent is the **signature gradient** `--grad-brand` (135°, electric blue `#2540B5` → violet `#7B2CBF`), used on the one primary action per view and on the brand mark. A `vivid` variant adds a magenta tail (matches the logo). Neutrals are purple-tinted greys so the whole UI reads cohesively warm-cool. Never use the old obsidian/deep-purple backgrounds.

**Type.** Display = **Plus Jakarta Sans** (geometric, friendly, professional) for headings, hero, and numbers, set tight (`-0.03em`). Body = **Inter** for UI text, forms, and paragraphs. Mono = **JetBrains Mono** for metrics, percentages, funding figures, and code. Headlines are bold/extrabold; body is regular/medium.

**Spacing & layout.** 4px base grid. Generous padding (cards 18–28px, sections 64px). Content maxes around 1080–1180px and is centered. Sidebar app shell is 232px. Forms are single-column, ≤ 560px.

**Corners.** Soft, never sharp: inputs/buttons `--radius-md` (12px), cards `--radius-lg` (16px), big panels `--radius-2xl` (28px), pills/badges full-round. The brand mark tile is a rounded square.

**Shadows.** Soft and **purple-tinted** (`rgba(45,27,92,…)`), low and diffuse — `xs → xl`. Cards rest on `sm`; on hover they lift to `lg`. Primary CTAs carry a violet **`--glow-brand`** halo. No hard black drop-shadows.

**Borders.** Hairline, 1px, in tinted neutrals (`--border-subtle` #ECE7F4). Brand-tinted borders (`--violet-200/300`) mark active/selected/branded surfaces.

**Backgrounds.** Mostly flat light surfaces. Accent moments use the gradient (CTA panel, brand mark) or a soft radial **halo** (`--grad-hero`) behind hero/auth content. Soft tint washes (`--grad-brand-soft`) for highlighted cards. No photographic imagery, no noise/grain, no repeating patterns.

**Motion.** Quick and confident: `--dur-base` 180ms on `--ease-out` (cubic-bezier(.22,1,.36,1)). Buttons depress 1px on `:active`; cards translateY(-2px) on hover. The deck-generation progress bar uses an animated barber-pole stripe. Reserve looping animation for genuine in-progress states only.

**States.**
- *Hover:* surfaces lift + brand-tint the border; ghost buttons fill with `--violet-50`; primary deepens its glow.
- *Press:* 1px downward nudge (`translateY(1px)`), slightly reduced opacity.
- *Focus:* 3px brand ring (`--focus-ring`, `rgba(123,44,191,.32)`).
- *Disabled:* 50% opacity, no transform.

**Cards** = white, 1px subtle border, `--shadow-sm`, 16px radius. Interactive cards lift and brand-tint their border on hover. A `gradient` card variant lays a soft blue→violet wash behind content.

---

## Iconography

- **System:** [Lucide](https://lucide.dev) — matches the codebase's `lucide-react` dependency exactly. Outline style, **2px** stroke, round caps/joins, 24×24 viewBox.
- **Implementation here:** a hand-ported subset lives in `ui_kits/app/icons.jsx` as an `<Icon name="…" />` component (`window.Icon`) drawing the real Lucide path data — same geometry, no external dependency. Names included: dashboard, plus, settings, billing, logout, sparkles, globe, clock, fileText, trendingUp, arrowRight/Left, play, download, edit, check, chevronDown/Right, search, externalLink, zap, target, barChart, users, rocket, layers, refresh.
- **To extend:** add the icon's Lucide path data to `ICON_PATHS` in `icons.jsx`, or in production simply `import { IconName } from "lucide-react"`.
- **Icon color:** inherits `currentColor` — muted in nav, violet on brand surfaces, white inside the gradient mark.
- **Emoji / unicode icons:** not used. The "sparkles" motif (AI) and stacked-chevron (the logo mark) are the brand's signature glyphs.
- **Sizes:** 14–16px inline with text, 18–20px in nav/stat tiles, 24–28px in the brand mark.

---

## Index / Manifest

**Root**
- `styles.css` — global entry point (import this); `@import`s the token + base files.
- `readme.md` — this guide.
- `SKILL.md` — Agent-Skill front-matter for Claude Code use.

**Tokens** (`tokens/`, all reachable from `styles.css`)
- `fonts.css` — Plus Jakarta Sans / Inter / JetBrains Mono (Google Fonts CDN — see Caveats).
- `colors.css` — violet/indigo/magenta/neutral scales, semantic hues, gradients, surface/text/border aliases.
- `typography.css` — families, weights, type scale, leading, tracking.
- `spacing.css` — 4px spacing scale, radii, containers, z-index.
- `effects.css` — purple-tinted shadows, glow, focus ring, motion easings/durations.
- `base.css` — element resets + brand helpers (`.ipr-gradient-text`, `.ipr-eyebrow`, `.ipr-mark`).

**Components** — `window.IPreneurDesignSystem_e030e0`
- `components/core/` — **Button**, **Card**, **Badge**, **Tag**, **Avatar**
- `components/forms/` — **Input**, **Select**, **Switch**, **Checkbox**
- `components/data/` — **ProgressBar**, **StatCard**, **Tabs**

**UI kits** (`ui_kits/`)
- `app/` — interactive iPreneur app: login → dashboard → new deck → generating workspace → ready deck preview.
- `marketing/` — light-theme landing page (hero, features, how-it-works, CTA).

**Design System tab cards** — foundation specimens in `guidelines/` (Colors, Type, Spacing, Brand) plus one `*.card.html` per component group.

---

## Caveats

- **Fonts are CDN-substituted.** No licensed binaries were provided, so `tokens/fonts.css` loads Plus Jakarta Sans, Inter, and JetBrains Mono from Google Fonts. Inter & JetBrains Mono match the codebase; **Plus Jakarta Sans is a new display choice** for character (the codebase used Inter for display). Drop real font files into `tokens/` and swap the `@import` for `@font-face` rules if you have them.
- **Light redesign, not a 1:1 clone.** The production app is dark; these kits are the requested light-purple reimagining.
