/* @ds-bundle: {"format":3,"namespace":"IPreneurDesignSystem_e030e0","components":[{"name":"Avatar","sourcePath":"components/core/Avatar.jsx"},{"name":"Badge","sourcePath":"components/core/Badge.jsx"},{"name":"Button","sourcePath":"components/core/Button.jsx"},{"name":"Card","sourcePath":"components/core/Card.jsx"},{"name":"Tag","sourcePath":"components/core/Tag.jsx"},{"name":"ProgressBar","sourcePath":"components/data/ProgressBar.jsx"},{"name":"StatCard","sourcePath":"components/data/StatCard.jsx"},{"name":"Tabs","sourcePath":"components/data/Tabs.jsx"},{"name":"Checkbox","sourcePath":"components/forms/Checkbox.jsx"},{"name":"Input","sourcePath":"components/forms/Input.jsx"},{"name":"Select","sourcePath":"components/forms/Select.jsx"},{"name":"Switch","sourcePath":"components/forms/Switch.jsx"}],"sourceHashes":{"components/core/Avatar.jsx":"07627fb760ca","components/core/Badge.jsx":"c0334396bc93","components/core/Button.jsx":"0b399324068a","components/core/Card.jsx":"1c05b08f3b85","components/core/Tag.jsx":"effab6043208","components/data/ProgressBar.jsx":"3aaaaee840c8","components/data/StatCard.jsx":"84e1c2bf4878","components/data/Tabs.jsx":"6351f6ffa941","components/forms/Checkbox.jsx":"65d67c647a4e","components/forms/Input.jsx":"cffa5665a03c","components/forms/Select.jsx":"02dc8dab6a4d","components/forms/Switch.jsx":"41a9371e1faf","ui_kits/app/App.jsx":"8b10f3061f3b","ui_kits/app/Dashboard.jsx":"f78b0bbabb57","ui_kits/app/Login.jsx":"2beffbe0f4bf","ui_kits/app/NewDeck.jsx":"b06a2e699211","ui_kits/app/Sidebar.jsx":"6de66594c48a","ui_kits/app/Workspace.jsx":"7cff19331e5d","ui_kits/app/icons.jsx":"a18e0279d3c8","ui_kits/marketing/Landing.jsx":"71c97b599dba"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.IPreneurDesignSystem_e030e0 = window.IPreneurDesignSystem_e030e0 || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/core/Avatar.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const CSS = `
.ipr-avatar{
  display:inline-flex; align-items:center; justify-content:center;
  font-family:var(--font-display); font-weight:var(--weight-bold);
  color:var(--text-on-brand); background:var(--grad-brand);
  border-radius:50%; overflow:hidden; flex-shrink:0; line-height:1;
  box-shadow:inset 0 0 0 1px rgba(255,255,255,.18);
}
.ipr-avatar img{ width:100%; height:100%; object-fit:cover; }
.ipr-avatar--sm{ width:28px; height:28px; font-size:11px; }
.ipr-avatar--md{ width:38px; height:38px; font-size:14px; }
.ipr-avatar--lg{ width:52px; height:52px; font-size:18px; }
.ipr-avatar--square{ border-radius:var(--radius-md); }
`;
function useStyle() {
  React.useEffect(() => {
    if (document.getElementById("ipr-avatar-css")) return;
    const s = document.createElement("style");
    s.id = "ipr-avatar-css";
    s.textContent = CSS;
    document.head.appendChild(s);
  }, []);
}
function initials(name = "") {
  const parts = name.trim().split(/\s+/).filter(Boolean);
  if (!parts.length) return "?";
  return (parts[0][0] + (parts[1]?.[0] ?? "")).toUpperCase();
}

/** Circular user/company avatar — image or gradient initials fallback. */
function Avatar({
  name = "",
  src,
  size = "md",
  square = false,
  className = "",
  style,
  ...props
}) {
  useStyle();
  const cls = ["ipr-avatar", `ipr-avatar--${size}`, square ? "ipr-avatar--square" : "", className].filter(Boolean).join(" ");
  return /*#__PURE__*/React.createElement("span", _extends({
    className: cls,
    style: style
  }, props), src ? /*#__PURE__*/React.createElement("img", {
    src: src,
    alt: name
  }) : initials(name));
}
Object.assign(__ds_scope, { Avatar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Avatar.jsx", error: String((e && e.message) || e) }); }

// components/core/Badge.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const CSS = `
.ipr-badge{
  display:inline-flex; align-items:center; gap:5px;
  font-family:var(--font-body); font-size:var(--text-xs); font-weight:var(--weight-semibold);
  line-height:1; padding:5px 9px; border-radius:var(--radius-pill);
  border:1px solid transparent; white-space:nowrap; letter-spacing:.005em;
}
.ipr-badge__dot{ width:6px; height:6px; border-radius:50%; background:currentColor; }
.ipr-badge--brand{ background:var(--violet-100); color:var(--violet-700); border-color:var(--violet-200); }
.ipr-badge--neutral{ background:var(--neutral-100); color:var(--neutral-700); border-color:var(--neutral-200); }
.ipr-badge--success{ background:var(--success-surface); color:var(--green-600); border-color:rgba(22,163,74,.2); }
.ipr-badge--warning{ background:var(--warning-surface); color:var(--amber-600); border-color:rgba(224,138,0,.2); }
.ipr-badge--danger{ background:var(--danger-surface); color:var(--red-600); border-color:rgba(220,38,38,.2); }
.ipr-badge--info{ background:var(--info-surface); color:var(--blue-600); border-color:rgba(37,99,235,.2); }
.ipr-badge--solid{ background:var(--grad-brand); color:var(--text-on-brand); border-color:transparent; }
`;
function useStyle() {
  React.useEffect(() => {
    if (document.getElementById("ipr-badge-css")) return;
    const s = document.createElement("style");
    s.id = "ipr-badge-css";
    s.textContent = CSS;
    document.head.appendChild(s);
  }, []);
}

/** Compact status / category label. */
function Badge({
  tone = "brand",
  dot = false,
  icon,
  className = "",
  children,
  ...props
}) {
  useStyle();
  const cls = ["ipr-badge", `ipr-badge--${tone}`, className].filter(Boolean).join(" ");
  return /*#__PURE__*/React.createElement("span", _extends({
    className: cls
  }, props), dot ? /*#__PURE__*/React.createElement("span", {
    className: "ipr-badge__dot"
  }) : null, icon ? /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex"
    },
    "aria-hidden": "true"
  }, icon) : null, children);
}
Object.assign(__ds_scope, { Badge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Badge.jsx", error: String((e && e.message) || e) }); }

// components/core/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const CSS = `
.ipr-btn{
  --_h:40px; --_px:18px; --_fs:var(--text-sm);
  display:inline-flex; align-items:center; justify-content:center; gap:8px;
  height:var(--_h); padding:0 var(--_px); font-family:var(--font-body);
  font-size:var(--_fs); font-weight:var(--weight-semibold);
  letter-spacing:-0.005em; line-height:1; white-space:nowrap;
  border-radius:var(--radius-md); border:1px solid transparent;
  cursor:pointer; user-select:none; text-decoration:none;
  transition:transform var(--dur-fast) var(--ease-out),
             box-shadow var(--dur-base) var(--ease-out),
             background var(--dur-base) var(--ease-out),
             color var(--dur-base) var(--ease-out),
             border-color var(--dur-base) var(--ease-out);
}
.ipr-btn:focus-visible{ outline:none; box-shadow:var(--focus-ring); }
.ipr-btn:active{ transform:translateY(1px); }
.ipr-btn[disabled]{ opacity:.5; cursor:not-allowed; transform:none; }

.ipr-btn--sm{ --_h:32px; --_px:13px; --_fs:var(--text-xs); border-radius:var(--radius-sm); }
.ipr-btn--lg{ --_h:48px; --_px:24px; --_fs:var(--text-base); border-radius:var(--radius-lg); }
.ipr-btn--block{ width:100%; }

.ipr-btn--primary{ background:var(--grad-brand); color:var(--text-on-brand); box-shadow:var(--glow-brand); }
.ipr-btn--primary:hover:not([disabled]){ box-shadow:0 10px 30px rgba(123,44,191,.40); filter:saturate(1.05); }

.ipr-btn--solid{ background:var(--brand); color:var(--text-on-brand); }
.ipr-btn--solid:hover:not([disabled]){ background:var(--brand-hover); }

.ipr-btn--secondary{ background:var(--surface-card); color:var(--text-body);
  border-color:var(--border-default); box-shadow:var(--shadow-xs); }
.ipr-btn--secondary:hover:not([disabled]){ border-color:var(--border-strong); color:var(--text-strong); background:var(--surface-hover); }

.ipr-btn--ghost{ background:transparent; color:var(--text-body); }
.ipr-btn--ghost:hover:not([disabled]){ background:var(--surface-brand); color:var(--text-brand); }

.ipr-btn--danger{ background:var(--danger-surface); color:var(--danger); border-color:rgba(220,38,38,.22); }
.ipr-btn--danger:hover:not([disabled]){ background:#fbdada; }

.ipr-btn__spin{ width:15px; height:15px; border-radius:50%;
  border:2px solid currentColor; border-top-color:transparent;
  animation:ipr-btn-spin .6s linear infinite; }
@keyframes ipr-btn-spin{ to{ transform:rotate(360deg); } }
`;
function useStyle() {
  React.useEffect(() => {
    if (document.getElementById("ipr-btn-css")) return;
    const s = document.createElement("style");
    s.id = "ipr-btn-css";
    s.textContent = CSS;
    document.head.appendChild(s);
  }, []);
}

/**
 * iPreneur Button — primary action control.
 */
function Button({
  variant = "secondary",
  size = "md",
  icon,
  iconRight,
  loading = false,
  fullWidth = false,
  disabled = false,
  as = "button",
  className = "",
  children,
  ...props
}) {
  useStyle();
  const Tag = as;
  const cls = ["ipr-btn", `ipr-btn--${variant}`, size !== "md" ? `ipr-btn--${size}` : "", fullWidth ? "ipr-btn--block" : "", className].filter(Boolean).join(" ");
  return /*#__PURE__*/React.createElement(Tag, _extends({
    className: cls,
    disabled: Tag === "button" ? disabled || loading : undefined
  }, props), loading ? /*#__PURE__*/React.createElement("span", {
    className: "ipr-btn__spin",
    "aria-hidden": "true"
  }) : icon ? /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex"
    },
    "aria-hidden": "true"
  }, icon) : null, children ? /*#__PURE__*/React.createElement("span", null, children) : null, !loading && iconRight ? /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex"
    },
    "aria-hidden": "true"
  }, iconRight) : null);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Button.jsx", error: String((e && e.message) || e) }); }

// components/core/Card.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const CSS = `
.ipr-card{
  background:var(--surface-card); border:1px solid var(--border-subtle);
  border-radius:var(--radius-lg); box-shadow:var(--shadow-sm);
  transition:transform var(--dur-base) var(--ease-out), box-shadow var(--dur-base) var(--ease-out), border-color var(--dur-base) var(--ease-out);
}
.ipr-card--pad{ padding:var(--space-6); }
.ipr-card--pad-sm{ padding:var(--space-4); }
.ipr-card--interactive{ cursor:pointer; }
.ipr-card--interactive:hover{ transform:translateY(-2px); box-shadow:var(--shadow-lg); border-color:var(--border-brand); }
.ipr-card--gradient{ position:relative; overflow:hidden; }
.ipr-card--gradient::before{ content:""; position:absolute; inset:0;
  background:var(--grad-brand-soft); opacity:.7; pointer-events:none; }
.ipr-card--gradient > *{ position:relative; }
.ipr-card--accent{ border-top:3px solid transparent; border-image:var(--grad-brand) 1; }
`;
function useStyle() {
  React.useEffect(() => {
    if (document.getElementById("ipr-card-css")) return;
    const s = document.createElement("style");
    s.id = "ipr-card-css";
    s.textContent = CSS;
    document.head.appendChild(s);
  }, []);
}

/** Surface container for grouping content. */
function Card({
  padding = "md",
  interactive = false,
  gradient = false,
  className = "",
  style,
  children,
  ...props
}) {
  useStyle();
  const cls = ["ipr-card", padding === "md" ? "ipr-card--pad" : padding === "sm" ? "ipr-card--pad-sm" : "", interactive ? "ipr-card--interactive" : "", gradient ? "ipr-card--gradient" : "", className].filter(Boolean).join(" ");
  return /*#__PURE__*/React.createElement("div", _extends({
    className: cls,
    style: style
  }, props), children);
}
Object.assign(__ds_scope, { Card });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Card.jsx", error: String((e && e.message) || e) }); }

// components/core/Tag.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const CSS = `
.ipr-tag{
  display:inline-flex; align-items:center; gap:6px;
  font-family:var(--font-body); font-size:var(--text-xs); font-weight:var(--weight-medium);
  line-height:1; padding:6px 10px; border-radius:var(--radius-sm);
  background:var(--surface-sunken); color:var(--text-body);
  border:1px solid var(--border-subtle);
}
.ipr-tag--brand{ background:var(--violet-50); color:var(--violet-700); border-color:var(--violet-200); }
.ipr-tag__x{ display:inline-flex; cursor:pointer; opacity:.55; margin-right:-2px;
  border:0; background:none; padding:0; color:inherit; font-size:13px; line-height:1; }
.ipr-tag__x:hover{ opacity:1; }
`;
function useStyle() {
  React.useEffect(() => {
    if (document.getElementById("ipr-tag-css")) return;
    const s = document.createElement("style");
    s.id = "ipr-tag-css";
    s.textContent = CSS;
    document.head.appendChild(s);
  }, []);
}

/** Input-style chip — keywords, filters, removable selections. */
function Tag({
  tone = "neutral",
  onRemove,
  icon,
  className = "",
  children,
  ...props
}) {
  useStyle();
  const cls = ["ipr-tag", tone === "brand" ? "ipr-tag--brand" : "", className].filter(Boolean).join(" ");
  return /*#__PURE__*/React.createElement("span", _extends({
    className: cls
  }, props), icon ? /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex"
    },
    "aria-hidden": "true"
  }, icon) : null, children, onRemove ? /*#__PURE__*/React.createElement("button", {
    type: "button",
    className: "ipr-tag__x",
    onClick: onRemove,
    "aria-label": "Remove"
  }, "\xD7") : null);
}
Object.assign(__ds_scope, { Tag });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Tag.jsx", error: String((e && e.message) || e) }); }

// components/data/ProgressBar.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const CSS = `
.ipr-prog{ display:flex; flex-direction:column; gap:8px; width:100%; }
.ipr-prog__top{ display:flex; align-items:center; justify-content:space-between;
  font-family:var(--font-body); font-size:var(--text-xs); color:var(--text-muted); }
.ipr-prog__pct{ font-family:var(--font-mono); font-weight:var(--weight-medium); color:var(--text-brand); }
.ipr-prog__track{ height:8px; border-radius:var(--radius-pill);
  background:var(--surface-sunken); overflow:hidden; }
.ipr-prog__track--sm{ height:5px; }
.ipr-prog__track--lg{ height:11px; }
.ipr-prog__fill{ height:100%; border-radius:var(--radius-pill);
  background:var(--grad-brand);
  transition:width var(--dur-slow) var(--ease-out); }
.ipr-prog__fill--striped{
  background-image:linear-gradient(135deg,var(--indigo-600),var(--violet-600)),
    linear-gradient(45deg,rgba(255,255,255,.18) 25%,transparent 25%,transparent 50%,rgba(255,255,255,.18) 50%,rgba(255,255,255,.18) 75%,transparent 75%);
  background-size:auto, 18px 18px;
  animation:ipr-prog-stripe 1s linear infinite;
}
@keyframes ipr-prog-stripe{ to{ background-position:0 0, 18px 0; } }
`;
function useStyle() {
  React.useEffect(() => {
    if (document.getElementById("ipr-prog-css")) return;
    const s = document.createElement("style");
    s.id = "ipr-prog-css";
    s.textContent = CSS;
    document.head.appendChild(s);
  }, []);
}

/** Linear progress bar with optional label + percentage. */
function ProgressBar({
  value = 0,
  label,
  showValue = false,
  size = "md",
  animated = false,
  className = "",
  style,
  ...props
}) {
  useStyle();
  const pct = Math.max(0, Math.min(100, value));
  return /*#__PURE__*/React.createElement("div", _extends({
    className: ["ipr-prog", className].filter(Boolean).join(" "),
    style: style
  }, props), label || showValue ? /*#__PURE__*/React.createElement("div", {
    className: "ipr-prog__top"
  }, /*#__PURE__*/React.createElement("span", null, label), showValue ? /*#__PURE__*/React.createElement("span", {
    className: "ipr-prog__pct"
  }, Math.round(pct), "%") : null) : null, /*#__PURE__*/React.createElement("div", {
    className: "ipr-prog__track" + (size !== "md" ? " ipr-prog__track--" + size : "")
  }, /*#__PURE__*/React.createElement("div", {
    className: "ipr-prog__fill" + (animated ? " ipr-prog__fill--striped" : ""),
    style: {
      width: pct + "%"
    }
  })));
}
Object.assign(__ds_scope, { ProgressBar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/ProgressBar.jsx", error: String((e && e.message) || e) }); }

// components/data/StatCard.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const CSS = `
.ipr-stat{
  display:flex; align-items:center; gap:14px;
  background:var(--surface-card); border:1px solid var(--border-subtle);
  border-radius:var(--radius-lg); padding:16px 18px; box-shadow:var(--shadow-xs);
}
.ipr-stat__icon{
  width:42px; height:42px; border-radius:var(--radius-md); flex-shrink:0;
  display:inline-flex; align-items:center; justify-content:center;
  background:var(--violet-100); color:var(--violet-600);
}
.ipr-stat__icon--grad{ background:var(--grad-brand); color:#fff; box-shadow:var(--glow-brand); }
.ipr-stat__body{ min-width:0; }
.ipr-stat__value{ font-family:var(--font-display); font-weight:var(--weight-bold);
  font-size:var(--text-xl); color:var(--text-strong); line-height:1.05; letter-spacing:-0.02em; }
.ipr-stat__label{ font-family:var(--font-body); font-size:var(--text-xs);
  color:var(--text-muted); margin-top:3px; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
.ipr-stat__delta{ font-family:var(--font-mono); font-size:var(--text-xs); font-weight:var(--weight-medium); }
.ipr-stat__delta--up{ color:var(--green-600); }
.ipr-stat__delta--down{ color:var(--red-600); }
`;
function useStyle() {
  React.useEffect(() => {
    if (document.getElementById("ipr-stat-css")) return;
    const s = document.createElement("style");
    s.id = "ipr-stat-css";
    s.textContent = CSS;
    document.head.appendChild(s);
  }, []);
}

/** Compact metric tile — icon, value, label, optional delta. */
function StatCard({
  icon,
  value,
  label,
  delta,
  gradientIcon = false,
  className = "",
  style,
  ...props
}) {
  useStyle();
  return /*#__PURE__*/React.createElement("div", _extends({
    className: ["ipr-stat", className].filter(Boolean).join(" "),
    style: style
  }, props), icon ? /*#__PURE__*/React.createElement("span", {
    className: "ipr-stat__icon" + (gradientIcon ? " ipr-stat__icon--grad" : ""),
    "aria-hidden": "true"
  }, icon) : null, /*#__PURE__*/React.createElement("div", {
    className: "ipr-stat__body"
  }, /*#__PURE__*/React.createElement("div", {
    className: "ipr-stat__value"
  }, value), /*#__PURE__*/React.createElement("div", {
    className: "ipr-stat__label"
  }, label, delta ? /*#__PURE__*/React.createElement("span", {
    className: "ipr-stat__delta ipr-stat__delta--" + (delta.dir || "up")
  }, " \xB7 ", delta.text) : null)));
}
Object.assign(__ds_scope, { StatCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/StatCard.jsx", error: String((e && e.message) || e) }); }

// components/data/Tabs.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const CSS = `
.ipr-tabs{ display:inline-flex; gap:4px; padding:4px; background:var(--surface-sunken);
  border:1px solid var(--border-subtle); border-radius:var(--radius-md); }
.ipr-tabs--full{ display:flex; width:100%; }
.ipr-tabs--full .ipr-tab{ flex:1; justify-content:center; }
.ipr-tab{
  display:inline-flex; align-items:center; gap:7px; border:0; cursor:pointer;
  font-family:var(--font-body); font-size:var(--text-sm); font-weight:var(--weight-semibold);
  color:var(--text-muted); background:transparent; padding:8px 15px;
  border-radius:var(--radius-sm); white-space:nowrap;
  transition:color var(--dur-base) var(--ease-out), background var(--dur-base) var(--ease-out), box-shadow var(--dur-base) var(--ease-out);
}
.ipr-tab:hover{ color:var(--text-strong); }
.ipr-tab--active{ color:var(--text-brand); background:var(--surface-card); box-shadow:var(--shadow-sm); }
.ipr-tab__count{ font-family:var(--font-mono); font-size:11px; padding:1px 7px;
  border-radius:var(--radius-pill); background:var(--violet-100); color:var(--violet-700); }
.ipr-tab--active .ipr-tab__count{ background:var(--violet-200); }
`;
function useStyle() {
  React.useEffect(() => {
    if (document.getElementById("ipr-tabs-css")) return;
    const s = document.createElement("style");
    s.id = "ipr-tabs-css";
    s.textContent = CSS;
    document.head.appendChild(s);
  }, []);
}

/** Segmented tab switcher (controlled). */
function Tabs({
  tabs = [],
  value,
  onChange,
  fullWidth = false,
  className = "",
  ...props
}) {
  useStyle();
  const cls = ["ipr-tabs", fullWidth ? "ipr-tabs--full" : "", className].filter(Boolean).join(" ");
  return /*#__PURE__*/React.createElement("div", _extends({
    className: cls,
    role: "tablist"
  }, props), tabs.map(t => {
    const tab = typeof t === "string" ? {
      value: t,
      label: t
    } : t;
    const active = tab.value === value;
    return /*#__PURE__*/React.createElement("button", {
      key: tab.value,
      type: "button",
      role: "tab",
      "aria-selected": active,
      className: "ipr-tab" + (active ? " ipr-tab--active" : ""),
      onClick: () => onChange && onChange(tab.value)
    }, tab.icon ? /*#__PURE__*/React.createElement("span", {
      style: {
        display: "inline-flex"
      },
      "aria-hidden": "true"
    }, tab.icon) : null, tab.label, tab.count != null ? /*#__PURE__*/React.createElement("span", {
      className: "ipr-tab__count"
    }, tab.count) : null);
  }));
}
Object.assign(__ds_scope, { Tabs });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/Tabs.jsx", error: String((e && e.message) || e) }); }

// components/forms/Checkbox.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const CSS = `
.ipr-check{ display:inline-flex; align-items:flex-start; gap:10px; cursor:pointer; user-select:none; }
.ipr-check--disabled{ opacity:.5; cursor:not-allowed; }
.ipr-check__box{
  width:20px; height:20px; border-radius:6px; flex-shrink:0; margin-top:1px;
  border:1.5px solid var(--border-strong); background:var(--surface-card);
  display:inline-flex; align-items:center; justify-content:center; color:#fff;
  transition:background var(--dur-fast) var(--ease-out), border-color var(--dur-fast) var(--ease-out);
}
.ipr-check__box--on{ background:var(--grad-brand); border-color:transparent; }
.ipr-check__box svg{ opacity:0; transform:scale(.6); transition:all var(--dur-fast) var(--ease-out); }
.ipr-check__box--on svg{ opacity:1; transform:scale(1); }
.ipr-check input{ position:absolute; opacity:0; width:0; height:0; }
.ipr-check:focus-within .ipr-check__box{ box-shadow:var(--focus-ring); }
.ipr-check__label{ font-family:var(--font-body); font-size:var(--text-sm); color:var(--text-body); line-height:1.4; }
`;
function useStyle() {
  React.useEffect(() => {
    if (document.getElementById("ipr-check-css")) return;
    const s = document.createElement("style");
    s.id = "ipr-check-css";
    s.textContent = CSS;
    document.head.appendChild(s);
  }, []);
}

/** Checkbox with gradient checked state. */
function Checkbox({
  checked = false,
  onChange,
  label,
  disabled = false,
  className = "",
  ...props
}) {
  useStyle();
  const cls = ["ipr-check", disabled ? "ipr-check--disabled" : "", className].filter(Boolean).join(" ");
  return /*#__PURE__*/React.createElement("label", {
    className: cls
  }, /*#__PURE__*/React.createElement("span", {
    className: "ipr-check__box" + (checked ? " ipr-check__box--on" : "")
  }, /*#__PURE__*/React.createElement("input", _extends({
    type: "checkbox",
    checked: checked,
    disabled: disabled,
    onChange: e => onChange && onChange(e.target.checked, e)
  }, props)), /*#__PURE__*/React.createElement("svg", {
    width: "13",
    height: "13",
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "3.4",
    strokeLinecap: "round",
    strokeLinejoin: "round"
  }, /*#__PURE__*/React.createElement("polyline", {
    points: "20 6 9 17 4 12"
  }))), label ? /*#__PURE__*/React.createElement("span", {
    className: "ipr-check__label"
  }, label) : null);
}
Object.assign(__ds_scope, { Checkbox });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Checkbox.jsx", error: String((e && e.message) || e) }); }

// components/forms/Input.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const CSS = `
.ipr-field{ display:flex; flex-direction:column; gap:7px; }
.ipr-field__label{ font-family:var(--font-body); font-size:var(--text-sm);
  font-weight:var(--weight-semibold); color:var(--text-strong); }
.ipr-field__hint{ font-size:var(--text-xs); color:var(--text-faint); }
.ipr-field__err{ font-size:var(--text-xs); color:var(--danger); font-weight:var(--weight-medium); }

.ipr-input-wrap{ position:relative; display:flex; align-items:center; }
.ipr-input-wrap__icon{ position:absolute; left:13px; display:inline-flex;
  color:var(--text-faint); pointer-events:none; }
.ipr-input{
  width:100%; height:44px; padding:0 14px; font-family:var(--font-body);
  font-size:var(--text-sm); color:var(--text-strong);
  background:var(--surface-card); border:1px solid var(--border-default);
  border-radius:var(--radius-md); outline:none;
  transition:border-color var(--dur-base) var(--ease-out), box-shadow var(--dur-base) var(--ease-out);
}
.ipr-input::placeholder{ color:var(--text-faint); }
.ipr-input:hover{ border-color:var(--border-strong); }
.ipr-input:focus{ border-color:var(--brand); box-shadow:var(--focus-ring); }
.ipr-input--icon{ padding-left:40px; }
.ipr-input--err{ border-color:var(--danger); }
.ipr-input--err:focus{ box-shadow:0 0 0 3px rgba(220,38,38,.18); }
.ipr-input:disabled{ background:var(--surface-sunken); color:var(--text-faint); cursor:not-allowed; }
textarea.ipr-input{ height:auto; padding:11px 14px; resize:vertical; line-height:1.5; }
`;
function useStyle() {
  React.useEffect(() => {
    if (document.getElementById("ipr-input-css")) return;
    const s = document.createElement("style");
    s.id = "ipr-input-css";
    s.textContent = CSS;
    document.head.appendChild(s);
  }, []);
}

/** Text field with optional label, leading icon, hint and error. */
function Input({
  label,
  hint,
  error,
  icon,
  id,
  multiline = false,
  rows = 4,
  className = "",
  style,
  ...props
}) {
  useStyle();
  const autoId = React.useId();
  const fieldId = id || autoId;
  const inputCls = ["ipr-input", icon ? "ipr-input--icon" : "", error ? "ipr-input--err" : "", className].filter(Boolean).join(" ");
  const Control = multiline ? "textarea" : "input";
  return /*#__PURE__*/React.createElement("div", {
    className: "ipr-field",
    style: style
  }, label ? /*#__PURE__*/React.createElement("label", {
    className: "ipr-field__label",
    htmlFor: fieldId
  }, label) : null, /*#__PURE__*/React.createElement("div", {
    className: "ipr-input-wrap"
  }, icon && !multiline ? /*#__PURE__*/React.createElement("span", {
    className: "ipr-input-wrap__icon",
    "aria-hidden": "true"
  }, icon) : null, /*#__PURE__*/React.createElement(Control, _extends({
    id: fieldId,
    className: inputCls,
    rows: multiline ? rows : undefined
  }, props))), error ? /*#__PURE__*/React.createElement("span", {
    className: "ipr-field__err"
  }, error) : hint ? /*#__PURE__*/React.createElement("span", {
    className: "ipr-field__hint"
  }, hint) : null);
}
Object.assign(__ds_scope, { Input });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Input.jsx", error: String((e && e.message) || e) }); }

// components/forms/Select.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const CSS = `
.ipr-select-field{ display:flex; flex-direction:column; gap:7px; }
.ipr-select-field__label{ font-family:var(--font-body); font-size:var(--text-sm);
  font-weight:var(--weight-semibold); color:var(--text-strong); }
.ipr-select-wrap{ position:relative; display:flex; align-items:center; }
.ipr-select{
  width:100%; height:44px; padding:0 38px 0 14px; font-family:var(--font-body);
  font-size:var(--text-sm); color:var(--text-strong); cursor:pointer;
  background:var(--surface-card); border:1px solid var(--border-default);
  border-radius:var(--radius-md); outline:none; appearance:none;
  transition:border-color var(--dur-base) var(--ease-out), box-shadow var(--dur-base) var(--ease-out);
}
.ipr-select:hover{ border-color:var(--border-strong); }
.ipr-select:focus{ border-color:var(--brand); box-shadow:var(--focus-ring); }
.ipr-select:disabled{ background:var(--surface-sunken); color:var(--text-faint); cursor:not-allowed; }
.ipr-select--placeholder{ color:var(--text-faint); }
.ipr-select-wrap__chev{ position:absolute; right:13px; pointer-events:none;
  color:var(--text-muted); display:inline-flex; }
`;
function useStyle() {
  React.useEffect(() => {
    if (document.getElementById("ipr-select-css")) return;
    const s = document.createElement("style");
    s.id = "ipr-select-css";
    s.textContent = CSS;
    document.head.appendChild(s);
  }, []);
}

/** Native select, styled to match Input. */
function Select({
  label,
  options = [],
  placeholder,
  id,
  value,
  className = "",
  style,
  ...props
}) {
  useStyle();
  const autoId = React.useId();
  const fieldId = id || autoId;
  const isPlaceholder = (value === "" || value == null) && placeholder;
  const cls = ["ipr-select", isPlaceholder ? "ipr-select--placeholder" : "", className].filter(Boolean).join(" ");
  return /*#__PURE__*/React.createElement("div", {
    className: "ipr-select-field",
    style: style
  }, label ? /*#__PURE__*/React.createElement("label", {
    className: "ipr-select-field__label",
    htmlFor: fieldId
  }, label) : null, /*#__PURE__*/React.createElement("div", {
    className: "ipr-select-wrap"
  }, /*#__PURE__*/React.createElement("select", _extends({
    id: fieldId,
    className: cls,
    value: value
  }, props), placeholder ? /*#__PURE__*/React.createElement("option", {
    value: ""
  }, placeholder) : null, options.map(o => {
    const opt = typeof o === "string" ? {
      value: o,
      label: o
    } : o;
    return /*#__PURE__*/React.createElement("option", {
      key: opt.value,
      value: opt.value
    }, opt.label);
  })), /*#__PURE__*/React.createElement("span", {
    className: "ipr-select-wrap__chev",
    "aria-hidden": "true"
  }, /*#__PURE__*/React.createElement("svg", {
    width: "14",
    height: "14",
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "2.4",
    strokeLinecap: "round",
    strokeLinejoin: "round"
  }, /*#__PURE__*/React.createElement("polyline", {
    points: "6 9 12 15 18 9"
  })))));
}
Object.assign(__ds_scope, { Select });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Select.jsx", error: String((e && e.message) || e) }); }

// components/forms/Switch.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const CSS = `
.ipr-switch{ display:inline-flex; align-items:center; gap:11px; cursor:pointer; user-select:none; }
.ipr-switch--disabled{ opacity:.5; cursor:not-allowed; }
.ipr-switch__track{
  position:relative; width:44px; height:26px; border-radius:var(--radius-pill);
  background:var(--neutral-300); transition:background var(--dur-base) var(--ease-out);
  flex-shrink:0;
}
.ipr-switch__track--on{ background:var(--grad-brand); }
.ipr-switch__thumb{
  position:absolute; top:3px; left:3px; width:20px; height:20px; border-radius:50%;
  background:#fff; box-shadow:var(--shadow-sm);
  transition:transform var(--dur-base) var(--ease-out);
}
.ipr-switch__track--on .ipr-switch__thumb{ transform:translateX(18px); }
.ipr-switch input{ position:absolute; opacity:0; width:0; height:0; }
.ipr-switch__label{ font-family:var(--font-body); font-size:var(--text-sm); color:var(--text-body); }
.ipr-switch:focus-within .ipr-switch__track{ box-shadow:var(--focus-ring); }
`;
function useStyle() {
  React.useEffect(() => {
    if (document.getElementById("ipr-switch-css")) return;
    const s = document.createElement("style");
    s.id = "ipr-switch-css";
    s.textContent = CSS;
    document.head.appendChild(s);
  }, []);
}

/** Toggle switch for binary settings. */
function Switch({
  checked = false,
  onChange,
  label,
  disabled = false,
  className = "",
  ...props
}) {
  useStyle();
  const cls = ["ipr-switch", disabled ? "ipr-switch--disabled" : "", className].filter(Boolean).join(" ");
  return /*#__PURE__*/React.createElement("label", {
    className: cls
  }, /*#__PURE__*/React.createElement("span", {
    className: "ipr-switch__track" + (checked ? " ipr-switch__track--on" : "")
  }, /*#__PURE__*/React.createElement("input", _extends({
    type: "checkbox",
    checked: checked,
    disabled: disabled,
    onChange: e => onChange && onChange(e.target.checked, e)
  }, props)), /*#__PURE__*/React.createElement("span", {
    className: "ipr-switch__thumb"
  })), label ? /*#__PURE__*/React.createElement("span", {
    className: "ipr-switch__label"
  }, label) : null);
}
Object.assign(__ds_scope, { Switch });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Switch.jsx", error: String((e && e.message) || e) }); }

// ui_kits/app/App.jsx
try { (() => {
// Interactive shell — state machine wiring all screens together.
const SEED_PROJECTS = [{
  id: 1,
  name: "Linear — Series B",
  company: "Linear",
  url: "linear.app",
  industry: "Dev Tools",
  status: "ready",
  colors: ["#5E6AD2", "#26282F"],
  updated: "2 hours ago",
  logo: null
}, {
  id: 2,
  name: "Ramp Growth Round",
  company: "Ramp",
  url: "ramp.com",
  industry: "Fintech",
  status: "ready",
  colors: ["#E8FE52", "#1A1A1A"],
  updated: "yesterday",
  logo: null
}, {
  id: 3,
  name: "Notion Series C",
  company: "Notion",
  url: "notion.so",
  industry: "Productivity",
  status: "generating",
  colors: ["#000000", "#F7F6F3"],
  updated: "just now",
  logo: null
}, {
  id: 4,
  name: "Figma Pitch",
  company: "Figma",
  url: "figma.com",
  industry: "Design",
  status: "draft",
  colors: ["#A259FF", "#F24E1E"],
  updated: "3 days ago",
  logo: null
}, {
  id: 5,
  name: "Vercel Seed",
  company: "Vercel",
  url: "vercel.com",
  industry: "Infrastructure",
  status: "ready",
  colors: ["#000000", "#0070F3"],
  updated: "5 days ago",
  logo: null
}, {
  id: 6,
  name: "Retool Series A",
  company: "Retool",
  url: "retool.com",
  industry: "Low-code",
  status: "draft",
  colors: ["#3B5BFE", "#1E1E1E"],
  updated: "1 week ago",
  logo: null
}];
const USER = {
  name: "Aanya Rao",
  plan: "Pro plan"
};
function App() {
  const [authed, setAuthed] = React.useState(false);
  const [screen, setScreen] = React.useState("dashboard");
  const [active, setActive] = React.useState(null);
  const [status, setStatus] = React.useState("ready");
  const [progress, setProgress] = React.useState(0);
  const timer = React.useRef(null);
  function openProject(p) {
    setActive(p);
    if (p.status === "generating") {
      startGen();
    } else {
      setStatus("ready");
    }
    setScreen("workspace");
  }
  function startGen() {
    setStatus("generating");
    setProgress(6);
    clearInterval(timer.current);
    timer.current = setInterval(() => {
      setProgress(v => {
        if (v >= 100) {
          clearInterval(timer.current);
          setStatus("ready");
          return 100;
        }
        return Math.min(100, v + 3.2);
      });
    }, 180);
  }
  function createDeck() {
    const p = {
      id: 99,
      name: "Linear — Series B",
      company: "Linear",
      url: "linear.app",
      industry: "Dev Tools",
      status: "generating",
      colors: ["#5E6AD2", "#26282F"],
      updated: "just now",
      logo: null
    };
    setActive(p);
    startGen();
    setScreen("workspace");
  }
  React.useEffect(() => () => clearInterval(timer.current), []);
  if (!authed) return /*#__PURE__*/React.createElement(window.Login, {
    onLogin: () => {
      setAuthed(true);
      setScreen("dashboard");
    }
  });
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      height: "100%",
      background: "var(--surface-page)"
    }
  }, /*#__PURE__*/React.createElement(window.Sidebar, {
    active: screen === "workspace" ? "dashboard" : screen,
    onNavigate: k => {
      setScreen(k === "new" ? "new" : k === "dashboard" ? "dashboard" : k);
    },
    onLogout: () => setAuthed(false),
    user: USER
  }), /*#__PURE__*/React.createElement("main", {
    style: {
      flex: 1,
      overflowY: "auto",
      position: "relative"
    }
  }, screen === "dashboard" && /*#__PURE__*/React.createElement(window.Dashboard, {
    user: USER,
    projects: SEED_PROJECTS,
    onOpen: openProject,
    onNew: () => setScreen("new")
  }), screen === "new" && /*#__PURE__*/React.createElement(window.NewDeck, {
    onBack: () => setScreen("dashboard"),
    onCreate: createDeck
  }), screen === "workspace" && active && /*#__PURE__*/React.createElement(window.Workspace, {
    project: active,
    status: status,
    progress: progress,
    onBack: () => setScreen("dashboard")
  }), (screen === "settings" || screen === "billing") && /*#__PURE__*/React.createElement(Placeholder, {
    title: screen === "settings" ? "Settings" : "Billing",
    onBack: () => setScreen("dashboard")
  })));
}
function Placeholder({
  title,
  onBack
}) {
  const {
    Button
  } = window.IPreneurDesignSystem_e030e0;
  const Icon = window.Icon;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 1180,
      margin: "0 auto",
      padding: "34px 38px"
    }
  }, /*#__PURE__*/React.createElement("h1", {
    style: {
      font: "800 32px var(--font-display)",
      letterSpacing: "-0.03em",
      color: "var(--text-strong)",
      marginBottom: 8
    }
  }, title), /*#__PURE__*/React.createElement("p", {
    style: {
      font: "400 14px var(--font-body)",
      color: "var(--text-muted)",
      marginBottom: 22
    }
  }, "This view isn't part of the kit preview."), /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    icon: /*#__PURE__*/React.createElement(Icon, {
      name: "arrowLeft",
      size: 15
    }),
    onClick: onBack
  }, "Back to dashboard"));
}
ReactDOM.createRoot(document.getElementById("root")).render(/*#__PURE__*/React.createElement(App, null));
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/app/App.jsx", error: String((e && e.message) || e) }); }

// ui_kits/app/Dashboard.jsx
try { (() => {
// Dashboard — greeting, stats, project grid.
function Dashboard({
  user,
  projects,
  onOpen,
  onNew
}) {
  const {
    Button,
    Card,
    Badge,
    StatCard,
    Tabs
  } = window.IPreneurDesignSystem_e030e0;
  const Icon = window.Icon;
  const [tab, setTab] = React.useState("all");
  const filtered = projects.filter(p => tab === "all" ? true : tab === "ready" ? p.status === "ready" : p.status === "draft" || p.status === "generating");
  const readyCount = projects.filter(p => p.status === "ready").length;
  const activeCount = projects.filter(p => p.status === "generating").length;
  const statusTone = {
    ready: "success",
    generating: "warning",
    draft: "neutral",
    error: "danger"
  };
  const statusLabel = {
    ready: "Ready",
    generating: "Generating",
    draft: "Draft",
    error: "Error"
  };
  return /*#__PURE__*/React.createElement("div", {
    style: dashStyles.page
  }, /*#__PURE__*/React.createElement("div", {
    style: dashStyles.header
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h1", {
    style: dashStyles.h1
  }, "Good afternoon, ", /*#__PURE__*/React.createElement("span", {
    className: "ipr-gradient-text"
  }, user.name.split(" ")[0])), /*#__PURE__*/React.createElement("p", {
    style: dashStyles.sub
  }, "You have ", projects.length, " pitch decks in your workspace")), /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    size: "lg",
    icon: /*#__PURE__*/React.createElement(Icon, {
      name: "plus",
      size: 16
    }),
    onClick: onNew
  }, "New Deck")), /*#__PURE__*/React.createElement("div", {
    style: dashStyles.stats
  }, /*#__PURE__*/React.createElement(StatCard, {
    icon: /*#__PURE__*/React.createElement(Icon, {
      name: "fileText"
    }),
    value: String(projects.length),
    label: "Total decks"
  }), /*#__PURE__*/React.createElement(StatCard, {
    gradientIcon: true,
    icon: /*#__PURE__*/React.createElement(Icon, {
      name: "check"
    }),
    value: String(readyCount),
    label: "Ready to pitch"
  }), /*#__PURE__*/React.createElement(StatCard, {
    icon: /*#__PURE__*/React.createElement(Icon, {
      name: "sparkles"
    }),
    value: String(activeCount),
    label: "In progress"
  }), /*#__PURE__*/React.createElement(StatCard, {
    icon: /*#__PURE__*/React.createElement(Icon, {
      name: "trendingUp"
    }),
    value: "$4.6M",
    label: "Tracked ARR"
  })), /*#__PURE__*/React.createElement("div", {
    style: dashStyles.toolbar
  }, /*#__PURE__*/React.createElement(Tabs, {
    value: tab,
    onChange: setTab,
    tabs: [{
      value: "all",
      label: "All",
      count: projects.length
    }, {
      value: "ready",
      label: "Ready",
      count: readyCount
    }, {
      value: "drafts",
      label: "Drafts",
      count: projects.length - readyCount
    }]
  })), /*#__PURE__*/React.createElement("div", {
    style: dashStyles.grid
  }, filtered.map(p => /*#__PURE__*/React.createElement(Card, {
    key: p.id,
    interactive: true,
    padding: "none",
    onClick: () => onOpen(p)
  }, /*#__PURE__*/React.createElement("div", {
    style: dashStyles.cardInner
  }, /*#__PURE__*/React.createElement("div", {
    style: dashStyles.cardTop
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: dashStyles.cardName
  }, p.name), /*#__PURE__*/React.createElement("div", {
    style: dashStyles.cardUrl
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "globe",
    size: 12
  }), " ", p.url)), /*#__PURE__*/React.createElement(Badge, {
    tone: statusTone[p.status],
    dot: true
  }, statusLabel[p.status])), /*#__PURE__*/React.createElement("div", {
    style: dashStyles.swatches
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      ...dashStyles.dot,
      background: p.colors[0]
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      ...dashStyles.dot,
      background: p.colors[1]
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: dashStyles.industry
  }, p.industry)), /*#__PURE__*/React.createElement("div", {
    style: dashStyles.cardFoot
  }, /*#__PURE__*/React.createElement("span", {
    style: dashStyles.time
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "clock",
    size: 12
  }), " ", p.updated), /*#__PURE__*/React.createElement(Icon, {
    name: "chevronRight",
    size: 15,
    style: {
      color: "var(--text-faint)"
    }
  })))))));
}
const dashStyles = {
  page: {
    padding: "34px 38px 48px",
    maxWidth: 1180,
    margin: "0 auto"
  },
  header: {
    display: "flex",
    alignItems: "flex-start",
    justifyContent: "space-between",
    gap: 20,
    marginBottom: 26
  },
  h1: {
    font: "800 32px var(--font-display)",
    letterSpacing: "-0.03em",
    color: "var(--text-strong)"
  },
  sub: {
    marginTop: 6,
    font: "400 14px var(--font-body)",
    color: "var(--text-muted)"
  },
  stats: {
    display: "grid",
    gridTemplateColumns: "repeat(4, 1fr)",
    gap: 14,
    marginBottom: 26
  },
  toolbar: {
    marginBottom: 18
  },
  grid: {
    display: "grid",
    gridTemplateColumns: "repeat(3, 1fr)",
    gap: 16
  },
  cardInner: {
    padding: 18,
    display: "flex",
    flexDirection: "column",
    gap: 14
  },
  cardTop: {
    display: "flex",
    alignItems: "flex-start",
    justifyContent: "space-between",
    gap: 10
  },
  cardName: {
    font: "700 15px var(--font-display)",
    color: "var(--text-strong)",
    whiteSpace: "nowrap",
    overflow: "hidden",
    textOverflow: "ellipsis"
  },
  cardUrl: {
    display: "flex",
    alignItems: "center",
    gap: 5,
    marginTop: 5,
    font: "400 12px var(--font-body)",
    color: "var(--text-faint)"
  },
  swatches: {
    display: "flex",
    alignItems: "center",
    gap: 7
  },
  dot: {
    width: 18,
    height: 18,
    borderRadius: 99,
    border: "1.5px solid #fff",
    boxShadow: "var(--shadow-xs)"
  },
  industry: {
    marginLeft: 4,
    font: "500 11px var(--font-body)",
    color: "var(--text-muted)",
    background: "var(--surface-sunken)",
    padding: "3px 9px",
    borderRadius: 99
  },
  cardFoot: {
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    paddingTop: 12,
    borderTop: "1px solid var(--border-subtle)"
  },
  time: {
    display: "flex",
    alignItems: "center",
    gap: 5,
    font: "400 12px var(--font-body)",
    color: "var(--text-faint)"
  }
};
window.Dashboard = Dashboard;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/app/Dashboard.jsx", error: String((e && e.message) || e) }); }

// ui_kits/app/Login.jsx
try { (() => {
// Login screen.
function Login({
  onLogin
}) {
  const {
    Button,
    Input
  } = window.IPreneurDesignSystem_e030e0;
  const Icon = window.Icon;
  return /*#__PURE__*/React.createElement("div", {
    style: loginStyles.wrap
  }, /*#__PURE__*/React.createElement("div", {
    style: loginStyles.halo
  }), /*#__PURE__*/React.createElement("div", {
    style: loginStyles.card
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/ipreneur-logo.webp",
    alt: "iPreneur",
    style: {
      width: 140,
      margin: "0 auto 26px",
      display: "block"
    }
  }), /*#__PURE__*/React.createElement("h1", {
    style: loginStyles.h1
  }, "Welcome back"), /*#__PURE__*/React.createElement("p", {
    style: loginStyles.sub
  }, "Sign in to your iPreneur account"), /*#__PURE__*/React.createElement("div", {
    style: loginStyles.form
  }, /*#__PURE__*/React.createElement(Input, {
    label: "Email",
    defaultValue: "aanya@foundry.vc",
    placeholder: "you@company.com"
  }), /*#__PURE__*/React.createElement(Input, {
    label: "Password",
    type: "password",
    defaultValue: "password",
    placeholder: "\u2022\u2022\u2022\u2022\u2022\u2022\u2022\u2022"
  }), /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    size: "lg",
    fullWidth: true,
    onClick: onLogin,
    iconRight: /*#__PURE__*/React.createElement(Icon, {
      name: "arrowRight",
      size: 16
    })
  }, "Sign in")), /*#__PURE__*/React.createElement("p", {
    style: loginStyles.foot
  }, "Don't have an account? ", /*#__PURE__*/React.createElement("a", {
    href: "#",
    onClick: e => {
      e.preventDefault();
      onLogin();
    },
    style: {
      color: "var(--text-link)",
      fontWeight: 600
    }
  }, "Sign up"))));
}
const loginStyles = {
  wrap: {
    minHeight: "100%",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    padding: 24,
    position: "relative",
    overflow: "hidden"
  },
  halo: {
    position: "absolute",
    inset: 0,
    background: "var(--grad-hero)",
    pointerEvents: "none"
  },
  card: {
    position: "relative",
    width: "100%",
    maxWidth: 400,
    background: "var(--surface-card)",
    border: "1px solid var(--border-subtle)",
    borderRadius: "var(--radius-xl)",
    boxShadow: "var(--shadow-lg)",
    padding: "38px 36px"
  },
  h1: {
    font: "800 26px var(--font-display)",
    letterSpacing: "-0.03em",
    color: "var(--text-strong)",
    textAlign: "center"
  },
  sub: {
    marginTop: 7,
    marginBottom: 26,
    font: "400 14px var(--font-body)",
    color: "var(--text-muted)",
    textAlign: "center"
  },
  form: {
    display: "flex",
    flexDirection: "column",
    gap: 16
  },
  foot: {
    marginTop: 22,
    textAlign: "center",
    font: "400 13px var(--font-body)",
    color: "var(--text-muted)"
  }
};
window.Login = Login;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/app/Login.jsx", error: String((e && e.message) || e) }); }

// ui_kits/app/NewDeck.jsx
try { (() => {
// New Deck — create form.
function NewDeck({
  onBack,
  onCreate
}) {
  const {
    Button,
    Card,
    Input,
    Select,
    Switch
  } = window.IPreneurDesignSystem_e030e0;
  const Icon = window.Icon;
  const [url, setUrl] = React.useState("https://linear.app");
  const [name, setName] = React.useState("Linear — Series B");
  const [stage, setStage] = React.useState("series_a");
  const [auto, setAuto] = React.useState(true);
  const examples = ["stripe.com", "notion.so", "figma.com", "ramp.com"];
  return /*#__PURE__*/React.createElement("div", {
    style: ndStyles.page
  }, /*#__PURE__*/React.createElement("button", {
    onClick: onBack,
    style: ndStyles.back
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "arrowLeft",
    size: 15
  }), " Dashboard"), /*#__PURE__*/React.createElement("div", {
    style: ndStyles.head
  }, /*#__PURE__*/React.createElement("div", {
    className: "ipr-mark",
    style: ndStyles.mark
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "sparkles",
    size: 26
  })), /*#__PURE__*/React.createElement("h1", {
    style: ndStyles.h1
  }, "Create your pitch deck"), /*#__PURE__*/React.createElement("p", {
    style: ndStyles.sub
  }, "Drop in a company URL. Our AI does the rest.")), /*#__PURE__*/React.createElement(Card, {
    padding: "none",
    style: {
      overflow: "hidden"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: ndStyles.form
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(Input, {
    label: "Company website",
    icon: /*#__PURE__*/React.createElement(Icon, {
      name: "globe",
      size: 16
    }),
    value: url,
    onChange: e => setUrl(e.target.value),
    placeholder: "https://yourcompany.com"
  }), /*#__PURE__*/React.createElement("div", {
    style: ndStyles.examples
  }, examples.map(e => /*#__PURE__*/React.createElement("button", {
    key: e,
    style: ndStyles.exBtn,
    onClick: () => setUrl("https://" + e)
  }, e)))), /*#__PURE__*/React.createElement(Input, {
    label: "Project name",
    value: name,
    onChange: e => setName(e.target.value),
    placeholder: "e.g. Series A deck"
  }), /*#__PURE__*/React.createElement("div", {
    style: ndStyles.twoCol
  }, /*#__PURE__*/React.createElement(Select, {
    label: "Funding stage",
    value: stage,
    onChange: e => setStage(e.target.value),
    options: [{
      value: "pre_seed",
      label: "Pre-seed"
    }, {
      value: "seed",
      label: "Seed"
    }, {
      value: "series_a",
      label: "Series A"
    }, {
      value: "series_b",
      label: "Series B"
    }, {
      value: "growth",
      label: "Growth"
    }]
  }), /*#__PURE__*/React.createElement(Select, {
    label: "Business model",
    placeholder: "AI will detect",
    options: ["SaaS", "Marketplace", "Fintech", "Ecommerce", "Hardware"]
  })), /*#__PURE__*/React.createElement("div", {
    style: ndStyles.toggleRow
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: ndStyles.toggleTitle
  }, "Generate immediately"), /*#__PURE__*/React.createElement("div", {
    style: ndStyles.toggleSub
  }, "Start AI analysis right after creating")), /*#__PURE__*/React.createElement(Switch, {
    checked: auto,
    onChange: setAuto
  })), /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    size: "lg",
    fullWidth: true,
    onClick: onCreate,
    iconRight: /*#__PURE__*/React.createElement(Icon, {
      name: "arrowRight",
      size: 16
    })
  }, "Create Deck"))), /*#__PURE__*/React.createElement("p", {
    style: ndStyles.trust
  }, "Analysis takes ~2 minutes \xB7 PPTX output \xB7 Fully editable"));
}
const ndStyles = {
  page: {
    maxWidth: 560,
    margin: "0 auto",
    padding: "30px 24px 60px",
    position: "relative"
  },
  back: {
    display: "inline-flex",
    alignItems: "center",
    gap: 6,
    border: 0,
    background: "none",
    cursor: "pointer",
    font: "500 13px var(--font-body)",
    color: "var(--text-muted)",
    marginBottom: 26
  },
  head: {
    textAlign: "center",
    marginBottom: 26
  },
  mark: {
    width: 56,
    height: 56,
    margin: "0 auto 16px"
  },
  h1: {
    font: "800 28px var(--font-display)",
    letterSpacing: "-0.03em",
    color: "var(--text-strong)"
  },
  sub: {
    marginTop: 7,
    font: "400 15px var(--font-body)",
    color: "var(--text-muted)"
  },
  form: {
    padding: 26,
    display: "flex",
    flexDirection: "column",
    gap: 18
  },
  examples: {
    display: "flex",
    flexWrap: "wrap",
    gap: 12,
    marginTop: 9
  },
  exBtn: {
    border: 0,
    background: "none",
    cursor: "pointer",
    font: "500 12px var(--font-body)",
    color: "var(--text-faint)"
  },
  twoCol: {
    display: "grid",
    gridTemplateColumns: "1fr 1fr",
    gap: 14
  },
  toggleRow: {
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    gap: 14,
    padding: "13px 16px",
    background: "var(--surface-sunken)",
    borderRadius: "var(--radius-md)"
  },
  toggleTitle: {
    font: "600 13px var(--font-body)",
    color: "var(--text-strong)"
  },
  toggleSub: {
    marginTop: 3,
    font: "400 12px var(--font-body)",
    color: "var(--text-muted)"
  },
  trust: {
    textAlign: "center",
    marginTop: 18,
    font: "400 12px var(--font-body)",
    color: "var(--text-faint)"
  }
};
window.NewDeck = NewDeck;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/app/NewDeck.jsx", error: String((e && e.message) || e) }); }

// ui_kits/app/Sidebar.jsx
try { (() => {
// iPreneur app sidebar — logo, nav, user card.
function Sidebar({
  active,
  onNavigate,
  onLogout,
  user
}) {
  const {
    Avatar
  } = window.IPreneurDesignSystem_e030e0;
  const Icon = window.Icon;
  const items = [{
    key: "dashboard",
    icon: "dashboard",
    label: "Dashboard"
  }, {
    key: "new",
    icon: "plus",
    label: "New Deck"
  }, {
    key: "settings",
    icon: "settings",
    label: "Settings"
  }, {
    key: "billing",
    icon: "billing",
    label: "Billing"
  }];
  return /*#__PURE__*/React.createElement("aside", {
    style: styles.aside
  }, /*#__PURE__*/React.createElement("div", {
    style: styles.logoWrap
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/ipreneur-logo.webp",
    alt: "iPreneur",
    style: {
      width: 124
    }
  })), /*#__PURE__*/React.createElement("nav", {
    style: styles.nav
  }, items.map(it => {
    const on = active === it.key;
    return /*#__PURE__*/React.createElement("button", {
      key: it.key,
      onClick: () => onNavigate(it.key),
      style: {
        ...styles.navItem,
        ...(on ? styles.navItemOn : {})
      }
    }, /*#__PURE__*/React.createElement(Icon, {
      name: it.icon,
      size: 18
    }), /*#__PURE__*/React.createElement("span", {
      style: {
        flex: 1,
        textAlign: "left"
      }
    }, it.label), on && /*#__PURE__*/React.createElement("span", {
      style: styles.navDot
    }));
  })), /*#__PURE__*/React.createElement("div", {
    style: styles.userCard
  }, /*#__PURE__*/React.createElement(Avatar, {
    name: user.name,
    size: "sm"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: styles.userName
  }, user.name), /*#__PURE__*/React.createElement("div", {
    style: styles.userRole
  }, user.plan)), /*#__PURE__*/React.createElement("button", {
    onClick: onLogout,
    title: "Sign out",
    style: styles.logoutBtn
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "logout",
    size: 15
  }))));
}
const styles = {
  aside: {
    width: 232,
    flexShrink: 0,
    display: "flex",
    flexDirection: "column",
    background: "var(--surface-card)",
    borderRight: "1px solid var(--border-subtle)"
  },
  logoWrap: {
    padding: "22px 22px 18px",
    borderBottom: "1px solid var(--border-subtle)"
  },
  nav: {
    flex: 1,
    padding: "16px 12px",
    display: "flex",
    flexDirection: "column",
    gap: 3
  },
  navItem: {
    display: "flex",
    alignItems: "center",
    gap: 12,
    padding: "10px 12px",
    borderRadius: "var(--radius-md)",
    border: "1px solid transparent",
    background: "transparent",
    color: "var(--text-muted)",
    font: "600 14px var(--font-body)",
    cursor: "pointer",
    transition: "var(--transition)",
    width: "100%"
  },
  navItemOn: {
    background: "var(--violet-50)",
    color: "var(--text-brand)",
    borderColor: "var(--violet-200)"
  },
  navDot: {
    width: 5,
    height: 16,
    borderRadius: 99,
    background: "var(--grad-brand)"
  },
  userCard: {
    margin: 12,
    padding: "10px 11px",
    display: "flex",
    alignItems: "center",
    gap: 11,
    borderRadius: "var(--radius-md)",
    background: "var(--surface-sunken)"
  },
  userName: {
    font: "600 12px var(--font-body)",
    color: "var(--text-strong)",
    whiteSpace: "nowrap",
    overflow: "hidden",
    textOverflow: "ellipsis"
  },
  userRole: {
    font: "500 11px var(--font-body)",
    color: "var(--text-muted)"
  },
  logoutBtn: {
    border: 0,
    background: "none",
    color: "var(--text-faint)",
    cursor: "pointer",
    display: "inline-flex",
    padding: 4
  }
};
window.Sidebar = Sidebar;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/app/Sidebar.jsx", error: String((e && e.message) || e) }); }

// ui_kits/app/Workspace.jsx
try { (() => {
// Workspace — generating progress + ready deck preview.
const JOB_STEPS = [{
  key: "crawling",
  label: "Crawling website"
}, {
  key: "extracting",
  label: "Extracting brand identity"
}, {
  key: "researching",
  label: "Researching market"
}, {
  key: "analyzing",
  label: "Analyzing investor potential"
}, {
  key: "generating",
  label: "Generating slide content"
}, {
  key: "rendering",
  label: "Rendering presentation"
}, {
  key: "uploading",
  label: "Finalizing & saving"
}];
const DECK_SLIDES = [{
  t: "Cover",
  k: "title"
}, {
  t: "Problem",
  k: "text"
}, {
  t: "Solution",
  k: "text"
}, {
  t: "Product",
  k: "image"
}, {
  t: "Market Size",
  k: "chart"
}, {
  t: "Business Model",
  k: "text"
}, {
  t: "Traction",
  k: "chart"
}, {
  t: "Competition",
  k: "grid"
}, {
  t: "Team",
  k: "team"
}, {
  t: "The Ask",
  k: "title"
}];
function Workspace({
  project,
  status,
  progress,
  onBack
}) {
  const {
    Button,
    Card,
    Badge,
    ProgressBar,
    Avatar
  } = window.IPreneurDesignSystem_e030e0;
  const Icon = window.Icon;
  const isGen = status === "generating";
  const stepIdx = Math.min(JOB_STEPS.length - 1, Math.floor(progress / 100 * JOB_STEPS.length));
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: wsStyles.topbar
  }, /*#__PURE__*/React.createElement("div", {
    style: wsStyles.topLeft
  }, /*#__PURE__*/React.createElement("button", {
    onClick: onBack,
    style: wsStyles.back
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "arrowLeft",
    size: 15
  }), " Dashboard"), /*#__PURE__*/React.createElement("span", {
    style: wsStyles.divider
  }), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: wsStyles.projName
  }, project.name), /*#__PURE__*/React.createElement("div", {
    style: wsStyles.projUrl
  }, project.url)), /*#__PURE__*/React.createElement(Badge, {
    tone: isGen ? "warning" : "success",
    dot: true
  }, isGen ? "Generating" : "Ready")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 10
    }
  }, !isGen && /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    icon: /*#__PURE__*/React.createElement(Icon, {
      name: "edit",
      size: 15
    })
  }, "Edit Deck"), !isGen && /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    icon: /*#__PURE__*/React.createElement(Icon, {
      name: "download",
      size: 15
    })
  }, "Export PPTX"))), /*#__PURE__*/React.createElement("div", {
    style: wsStyles.body
  }, /*#__PURE__*/React.createElement("aside", {
    style: wsStyles.aside
  }, /*#__PURE__*/React.createElement(Card, {
    padding: "none"
  }, /*#__PURE__*/React.createElement("div", {
    style: wsStyles.brandHead
  }, /*#__PURE__*/React.createElement(Avatar, {
    name: project.company,
    square: true,
    size: "lg",
    src: project.logo
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: wsStyles.brandName
  }, project.company), /*#__PURE__*/React.createElement("div", {
    style: wsStyles.brandUrl
  }, project.url))), /*#__PURE__*/React.createElement("div", {
    style: wsStyles.brandBody
  }, /*#__PURE__*/React.createElement("div", {
    style: wsStyles.metaRow
  }, /*#__PURE__*/React.createElement("span", {
    style: wsStyles.metaK
  }, "Industry"), /*#__PURE__*/React.createElement("span", {
    style: wsStyles.metaV
  }, project.industry)), /*#__PURE__*/React.createElement("div", {
    style: wsStyles.metaRow
  }, /*#__PURE__*/React.createElement("span", {
    style: wsStyles.metaK
  }, "Stage"), /*#__PURE__*/React.createElement("span", {
    style: wsStyles.metaV
  }, "Series A")), /*#__PURE__*/React.createElement("div", {
    style: wsStyles.metaRow
  }, /*#__PURE__*/React.createElement("span", {
    style: wsStyles.metaK
  }, "Ask"), /*#__PURE__*/React.createElement("span", {
    style: wsStyles.metaV
  }, "$1.5M")), /*#__PURE__*/React.createElement("div", {
    style: {
      ...wsStyles.metaRow,
      borderBottom: 0
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: wsStyles.metaK
  }, "Palette"), /*#__PURE__*/React.createElement("span", {
    style: {
      display: "flex",
      gap: 5
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      ...wsStyles.swatch,
      background: project.colors[0]
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      ...wsStyles.swatch,
      background: project.colors[1]
    }
  })))))), /*#__PURE__*/React.createElement("main", {
    style: {
      minWidth: 0
    }
  }, isGen ? /*#__PURE__*/React.createElement(Card, null, /*#__PURE__*/React.createElement("div", {
    style: wsStyles.genHead
  }, /*#__PURE__*/React.createElement("div", {
    className: "ipr-mark",
    style: {
      width: 38,
      height: 38,
      borderRadius: "var(--radius-md)"
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "sparkles",
    size: 18
  })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: wsStyles.genTitle
  }, "AI analysis in progress"), /*#__PURE__*/React.createElement("div", {
    style: wsStyles.genSub
  }, JOB_STEPS[stepIdx].label, "\u2026"))), /*#__PURE__*/React.createElement("div", {
    style: {
      margin: "22px 0 26px"
    }
  }, /*#__PURE__*/React.createElement(ProgressBar, {
    value: progress,
    label: "Overall progress",
    showValue: true,
    animated: true
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 8
    }
  }, JOB_STEPS.map((s, i) => {
    const done = i < stepIdx,
      cur = i === stepIdx;
    return /*#__PURE__*/React.createElement("div", {
      key: s.key,
      style: {
        ...wsStyles.step,
        ...(cur ? wsStyles.stepCur : {}),
        opacity: i > stepIdx ? 0.4 : 1
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        ...wsStyles.stepIcon,
        ...(done ? wsStyles.stepDone : cur ? wsStyles.stepCurIcon : wsStyles.stepPend)
      }
    }, done ? /*#__PURE__*/React.createElement(Icon, {
      name: "check",
      size: 13
    }) : /*#__PURE__*/React.createElement("span", {
      style: {
        font: "600 11px var(--font-mono)"
      }
    }, i + 1)), /*#__PURE__*/React.createElement("span", {
      style: {
        flex: 1,
        font: cur ? "600 14px var(--font-body)" : "500 14px var(--font-body)",
        color: cur ? "var(--text-strong)" : "var(--text-muted)"
      }
    }, s.label), done && /*#__PURE__*/React.createElement("span", {
      style: wsStyles.stepStatus
    }, "Done"), cur && /*#__PURE__*/React.createElement("span", {
      style: {
        font: "500 12px var(--font-mono)",
        color: "var(--text-brand)"
      }
    }, "Working\u2026"));
  }))) : /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: wsStyles.previewHead
  }, /*#__PURE__*/React.createElement("h2", {
    style: wsStyles.previewTitle
  }, "Generated deck"), /*#__PURE__*/React.createElement("span", {
    style: wsStyles.previewMeta
  }, DECK_SLIDES.length, " slides \xB7 16:9 \xB7 PPTX")), /*#__PURE__*/React.createElement("div", {
    style: wsStyles.slideGrid
  }, DECK_SLIDES.map((s, i) => /*#__PURE__*/React.createElement(SlideThumb, {
    key: i,
    index: i,
    slide: s,
    project: project
  })))))));
}
function SlideThumb({
  index,
  slide,
  project
}) {
  const isCover = slide.k === "title";
  return /*#__PURE__*/React.createElement("div", {
    style: wsStyles.slide
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      ...wsStyles.slideCanvas,
      ...(isCover ? {
        background: "var(--grad-brand)"
      } : {})
    }
  }, isCover ? /*#__PURE__*/React.createElement("div", {
    style: wsStyles.coverInner
  }, /*#__PURE__*/React.createElement("div", {
    style: wsStyles.coverDot
  }), /*#__PURE__*/React.createElement("div", {
    style: wsStyles.coverTitle
  }, project.company), /*#__PURE__*/React.createElement("div", {
    style: wsStyles.coverSub
  }, slide.t === "Cover" ? "Series A · 2026" : "$1.5M Round")) : /*#__PURE__*/React.createElement("div", {
    style: wsStyles.slideInner
  }, /*#__PURE__*/React.createElement("div", {
    style: wsStyles.slideBar
  }), slide.k === "chart" && /*#__PURE__*/React.createElement("div", {
    style: wsStyles.chart
  }, [40, 62, 48, 78, 95].map((h, j) => /*#__PURE__*/React.createElement("span", {
    key: j,
    style: {
      ...wsStyles.chartBar,
      height: h + "%"
    }
  }))), slide.k === "grid" && /*#__PURE__*/React.createElement("div", {
    style: wsStyles.miniGrid
  }, [0, 1, 2, 3].map(j => /*#__PURE__*/React.createElement("span", {
    key: j,
    style: wsStyles.miniCell
  }))), slide.k === "team" && /*#__PURE__*/React.createElement("div", {
    style: wsStyles.team
  }, [0, 1, 2].map(j => /*#__PURE__*/React.createElement("span", {
    key: j,
    style: wsStyles.teamDot
  }))), slide.k === "image" && /*#__PURE__*/React.createElement("div", {
    style: wsStyles.imgBlock
  }), slide.k === "text" && /*#__PURE__*/React.createElement("div", {
    style: wsStyles.lines
  }, [100, 82, 90, 68].map((w, j) => /*#__PURE__*/React.createElement("span", {
    key: j,
    style: {
      ...wsStyles.line,
      width: w + "%"
    }
  }))))), /*#__PURE__*/React.createElement("div", {
    style: wsStyles.slideLabel
  }, /*#__PURE__*/React.createElement("span", {
    style: wsStyles.slideNum
  }, String(index + 1).padStart(2, "0")), " ", slide.t));
}
const wsStyles = {
  topbar: {
    position: "sticky",
    top: 0,
    zIndex: 10,
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    gap: 16,
    padding: "14px 28px",
    background: "rgba(255,255,255,0.82)",
    backdropFilter: "blur(10px)",
    borderBottom: "1px solid var(--border-subtle)"
  },
  topLeft: {
    display: "flex",
    alignItems: "center",
    gap: 16,
    minWidth: 0
  },
  back: {
    display: "inline-flex",
    alignItems: "center",
    gap: 6,
    border: 0,
    background: "none",
    cursor: "pointer",
    font: "500 13px var(--font-body)",
    color: "var(--text-muted)"
  },
  divider: {
    width: 1,
    height: 18,
    background: "var(--border-default)"
  },
  projName: {
    font: "700 14px var(--font-display)",
    color: "var(--text-strong)"
  },
  projUrl: {
    font: "400 12px var(--font-body)",
    color: "var(--text-faint)"
  },
  body: {
    display: "grid",
    gridTemplateColumns: "300px 1fr",
    gap: 26,
    maxWidth: 1180,
    margin: "0 auto",
    padding: "28px 28px 50px"
  },
  aside: {},
  brandHead: {
    display: "flex",
    alignItems: "center",
    gap: 12,
    padding: 18,
    borderBottom: "1px solid var(--border-subtle)"
  },
  brandName: {
    font: "700 15px var(--font-display)",
    color: "var(--text-strong)"
  },
  brandUrl: {
    font: "400 12px var(--font-body)",
    color: "var(--text-faint)"
  },
  brandBody: {
    padding: "6px 18px 12px"
  },
  metaRow: {
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    padding: "11px 0",
    borderBottom: "1px solid var(--border-subtle)"
  },
  metaK: {
    font: "500 12px var(--font-body)",
    color: "var(--text-muted)"
  },
  metaV: {
    font: "600 13px var(--font-body)",
    color: "var(--text-strong)"
  },
  swatch: {
    width: 18,
    height: 18,
    borderRadius: 6,
    border: "1.5px solid #fff",
    boxShadow: "var(--shadow-xs)"
  },
  genHead: {
    display: "flex",
    alignItems: "center",
    gap: 13
  },
  genTitle: {
    font: "700 17px var(--font-display)",
    color: "var(--text-strong)"
  },
  genSub: {
    marginTop: 3,
    font: "400 13px var(--font-body)",
    color: "var(--text-muted)"
  },
  step: {
    display: "flex",
    alignItems: "center",
    gap: 14,
    padding: "10px 13px",
    borderRadius: "var(--radius-md)",
    border: "1px solid transparent",
    transition: "var(--transition)"
  },
  stepCur: {
    background: "var(--surface-sunken)",
    borderColor: "var(--border-subtle)"
  },
  stepIcon: {
    width: 26,
    height: 26,
    borderRadius: 99,
    display: "inline-flex",
    alignItems: "center",
    justifyContent: "center",
    flexShrink: 0
  },
  stepDone: {
    background: "var(--success-surface)",
    color: "var(--green-600)"
  },
  stepCurIcon: {
    background: "var(--grad-brand)",
    color: "#fff"
  },
  stepPend: {
    background: "var(--surface-sunken)",
    color: "var(--text-faint)",
    border: "1px solid var(--border-subtle)"
  },
  stepStatus: {
    font: "500 12px var(--font-body)",
    color: "var(--green-600)"
  },
  previewHead: {
    display: "flex",
    alignItems: "baseline",
    justifyContent: "space-between",
    marginBottom: 18
  },
  previewTitle: {
    font: "800 22px var(--font-display)",
    letterSpacing: "-0.02em",
    color: "var(--text-strong)"
  },
  previewMeta: {
    font: "500 12px var(--font-mono)",
    color: "var(--text-muted)"
  },
  slideGrid: {
    display: "grid",
    gridTemplateColumns: "repeat(3, 1fr)",
    gap: 16
  },
  slide: {
    display: "flex",
    flexDirection: "column",
    gap: 8
  },
  slideCanvas: {
    aspectRatio: "16/9",
    borderRadius: "var(--radius-md)",
    background: "var(--surface-card)",
    border: "1px solid var(--border-subtle)",
    boxShadow: "var(--shadow-sm)",
    overflow: "hidden",
    padding: 14
  },
  slideInner: {
    height: "100%",
    display: "flex",
    flexDirection: "column",
    gap: 9
  },
  slideBar: {
    width: "44%",
    height: 7,
    borderRadius: 99,
    background: "var(--violet-200)"
  },
  lines: {
    display: "flex",
    flexDirection: "column",
    gap: 6,
    marginTop: 2
  },
  line: {
    height: 5,
    borderRadius: 99,
    background: "var(--neutral-200)"
  },
  chart: {
    flex: 1,
    display: "flex",
    alignItems: "flex-end",
    gap: 8,
    paddingTop: 6
  },
  chartBar: {
    flex: 1,
    borderRadius: "3px 3px 0 0",
    background: "var(--grad-brand)"
  },
  miniGrid: {
    flex: 1,
    display: "grid",
    gridTemplateColumns: "1fr 1fr",
    gap: 7,
    paddingTop: 4
  },
  miniCell: {
    borderRadius: 6,
    background: "var(--surface-sunken)",
    border: "1px solid var(--border-subtle)"
  },
  team: {
    flex: 1,
    display: "flex",
    alignItems: "center",
    gap: 10
  },
  teamDot: {
    width: 30,
    height: 30,
    borderRadius: 99,
    background: "var(--violet-100)",
    border: "1.5px solid var(--violet-200)"
  },
  imgBlock: {
    flex: 1,
    borderRadius: 8,
    background: "var(--grad-brand-soft)",
    border: "1px solid var(--violet-100)"
  },
  coverInner: {
    height: "100%",
    display: "flex",
    flexDirection: "column",
    justifyContent: "flex-end",
    gap: 6,
    color: "#fff"
  },
  coverDot: {
    width: 22,
    height: 22,
    borderRadius: 7,
    background: "rgba(255,255,255,0.9)",
    marginBottom: "auto"
  },
  coverTitle: {
    font: "800 17px var(--font-display)",
    letterSpacing: "-0.02em"
  },
  coverSub: {
    font: "500 12px var(--font-body)",
    opacity: 0.85
  },
  slideLabel: {
    display: "flex",
    alignItems: "center",
    gap: 8,
    font: "500 12px var(--font-body)",
    color: "var(--text-muted)"
  },
  slideNum: {
    font: "600 11px var(--font-mono)",
    color: "var(--text-faint)"
  }
};
window.Workspace = Workspace;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/app/Workspace.jsx", error: String((e && e.message) || e) }); }

// ui_kits/app/icons.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
// Lucide-style icon set (stroke 2, 24×24) — matches the product's lucide-react usage.
const ICON_PATHS = {
  dashboard: '<rect x="3" y="3" width="7" height="9" rx="1.5"/><rect x="14" y="3" width="7" height="5" rx="1.5"/><rect x="14" y="12" width="7" height="9" rx="1.5"/><rect x="3" y="16" width="7" height="5" rx="1.5"/>',
  plus: '<path d="M12 5v14M5 12h14"/>',
  settings: '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/>',
  billing: '<rect x="2" y="5" width="20" height="14" rx="2.5"/><path d="M2 10h20"/>',
  logout: '<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/>',
  sparkles: '<path d="M12 3l1.9 4.6L18.5 9.5l-4.6 1.9L12 16l-1.9-4.6L5.5 9.5l4.6-1.9z"/><path d="M19 14l.9 2.1L22 17l-2.1.9L19 20l-.9-2.1L16 17l2.1-.9z"/>',
  globe: '<circle cx="12" cy="12" r="10"/><line x1="2" y1="12" x2="22" y2="12"/><path d="M12 2a15 15 0 0 1 0 20 15 15 0 0 1 0-20z"/>',
  clock: '<circle cx="12" cy="12" r="9"/><polyline points="12 7 12 12 15 14"/>',
  fileText: '<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="9" y1="13" x2="15" y2="13"/><line x1="9" y1="17" x2="13" y2="17"/>',
  trendingUp: '<polyline points="22 7 13.5 15.5 8.5 10.5 2 17"/><polyline points="16 7 22 7 22 13"/>',
  arrowRight: '<line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/>',
  arrowLeft: '<line x1="19" y1="12" x2="5" y2="12"/><polyline points="12 19 5 12 12 5"/>',
  play: '<polygon points="6 4 20 12 6 20 6 4"/>',
  download: '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/>',
  edit: '<path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.12 2.12 0 0 1 3 3L12 15l-4 1 1-4z"/>',
  check: '<polyline points="20 6 9 17 4 12"/>',
  chevronDown: '<polyline points="6 9 12 15 18 9"/>',
  chevronRight: '<polyline points="9 6 15 12 9 18"/>',
  search: '<circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>',
  externalLink: '<path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/>',
  zap: '<polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/>',
  target: '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1.4"/>',
  barChart: '<line x1="12" y1="20" x2="12" y2="10"/><line x1="18" y1="20" x2="18" y2="4"/><line x1="6" y1="20" x2="6" y2="16"/>',
  users: '<path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/>',
  rocket: '<path d="M4.5 16.5c-1.5 1.26-2 5-2 5s3.74-.5 5-2c.71-.84.7-2.13-.09-2.91a2.18 2.18 0 0 0-2.91-.09z"/><path d="M12 15l-3-3a22 22 0 0 1 2-3.95A12.88 12.88 0 0 1 22 2c0 2.72-.78 7.5-6 11a22.35 22.35 0 0 1-4 2z"/><path d="M9 12H4s.55-3.03 2-4c1.62-1.08 5 0 5 0"/><path d="M12 15v5s3.03-.55 4-2c1.08-1.62 0-5 0-5"/>',
  layers: '<polygon points="12 2 2 7 12 12 22 7 12 2"/><polyline points="2 17 12 22 22 17"/><polyline points="2 12 12 17 22 12"/>',
  refresh: '<polyline points="23 4 23 10 17 10"/><path d="M20.49 15a9 9 0 1 1-2.12-9.36L23 10"/>'
};
function Icon({
  name,
  size = 18,
  strokeWidth = 2,
  style,
  ...props
}) {
  return /*#__PURE__*/React.createElement("svg", _extends({
    width: size,
    height: size,
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: strokeWidth,
    strokeLinecap: "round",
    strokeLinejoin: "round",
    style: style,
    "aria-hidden": "true"
  }, props, {
    dangerouslySetInnerHTML: {
      __html: ICON_PATHS[name] || ""
    }
  }));
}
window.Icon = Icon;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/app/icons.jsx", error: String((e && e.message) || e) }); }

// ui_kits/marketing/Landing.jsx
try { (() => {
// iPreneur marketing landing page — light theme.
function Landing() {
  const {
    Button,
    Badge,
    Card
  } = window.IPreneurDesignSystem_e030e0;
  const Icon = window.Icon;
  const features = [{
    icon: "target",
    title: "Market research, automated",
    desc: "iPreneur researches your industry, competitors, and market size — no spreadsheets, no guesswork."
  }, {
    icon: "sparkles",
    title: "AI-crafted narrative",
    desc: "Claude writes a compelling story for every slide: problem, solution, traction, and the ask."
  }, {
    icon: "barChart",
    title: "Export & share",
    desc: "Download a polished, fully-editable PPTX or PDF — ready to send to investors in one click."
  }];
  const steps = [{
    n: "01",
    t: "Drop a URL",
    d: "Paste your company website. That's the only input we need to start."
  }, {
    n: "02",
    t: "AI analyzes",
    d: "We crawl your site, extract your brand, and research your market in ~2 minutes."
  }, {
    n: "03",
    t: "Get your deck",
    d: "A 10-slide, investor-ready pitch deck — on-brand and editable."
  }];
  const logos = ["Linear", "Ramp", "Notion", "Figma", "Vercel", "Retool"];
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("nav", {
    style: lp.nav
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/ipreneur-logo.webp",
    alt: "iPreneur",
    style: {
      width: 122
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: lp.navLinks
  }, /*#__PURE__*/React.createElement("a", {
    href: "#features",
    style: lp.navLink
  }, "Features"), /*#__PURE__*/React.createElement("a", {
    href: "#how",
    style: lp.navLink
  }, "How it works"), /*#__PURE__*/React.createElement("a", {
    href: "#pricing",
    style: lp.navLink
  }, "Pricing")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 10
    }
  }, /*#__PURE__*/React.createElement("a", {
    href: "#",
    style: lp.signin
  }, "Sign in"), /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    icon: /*#__PURE__*/React.createElement(Icon, {
      name: "sparkles",
      size: 15
    })
  }, "Get started"))), /*#__PURE__*/React.createElement("header", {
    style: lp.hero
  }, /*#__PURE__*/React.createElement("div", {
    style: lp.halo
  }), /*#__PURE__*/React.createElement("div", {
    style: lp.heroInner
  }, /*#__PURE__*/React.createElement("div", {
    style: lp.eyebrowPill
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "zap",
    size: 13,
    style: {
      color: "var(--violet-600)"
    }
  }), /*#__PURE__*/React.createElement("span", null, "AI-powered pitch decks \xB7 Backed by a startup accelerator")), /*#__PURE__*/React.createElement("h1", {
    style: lp.h1
  }, "Turn your idea into an", /*#__PURE__*/React.createElement("br", null), /*#__PURE__*/React.createElement("span", {
    className: "ipr-gradient-text"
  }, "investor-ready"), " pitch deck"), /*#__PURE__*/React.createElement("p", {
    style: lp.lead
  }, "iPreneur crawls your company website, researches your market, and generates a professional pitch deck tailored for investors \u2014 in under five minutes."), /*#__PURE__*/React.createElement("div", {
    style: lp.heroCtas
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    size: "lg",
    iconRight: /*#__PURE__*/React.createElement(Icon, {
      name: "arrowRight",
      size: 16
    })
  }, "Generate your deck"), /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    size: "lg",
    icon: /*#__PURE__*/React.createElement(Icon, {
      name: "play",
      size: 14
    })
  }, "Watch demo")), /*#__PURE__*/React.createElement("div", {
    style: lp.heroTrust
  }, /*#__PURE__*/React.createElement("span", null, /*#__PURE__*/React.createElement("b", {
    style: {
      color: "var(--text-strong)"
    }
  }, "12,000+"), " decks generated"), /*#__PURE__*/React.createElement("span", {
    style: lp.trustDivider
  }), /*#__PURE__*/React.createElement("span", null, /*#__PURE__*/React.createElement("b", {
    style: {
      color: "var(--text-strong)"
    }
  }, "~2 min"), " average build"), /*#__PURE__*/React.createElement("span", {
    style: lp.trustDivider
  }), /*#__PURE__*/React.createElement("span", null, "PPTX & PDF export")))), /*#__PURE__*/React.createElement("section", {
    style: lp.logosWrap
  }, /*#__PURE__*/React.createElement("span", {
    style: lp.logosLabel
  }, "Pitch decks built for founders raising at"), /*#__PURE__*/React.createElement("div", {
    style: lp.logos
  }, logos.map(l => /*#__PURE__*/React.createElement("span", {
    key: l,
    style: lp.logo
  }, l)))), /*#__PURE__*/React.createElement("section", {
    id: "features",
    style: lp.section
  }, /*#__PURE__*/React.createElement("div", {
    style: lp.sectionHead
  }, /*#__PURE__*/React.createElement("span", {
    className: "ipr-eyebrow"
  }, "Everything in one flow"), /*#__PURE__*/React.createElement("h2", {
    style: lp.h2
  }, "From URL to investor deck, automatically")), /*#__PURE__*/React.createElement("div", {
    style: lp.featGrid
  }, features.map(f => /*#__PURE__*/React.createElement(Card, {
    key: f.title,
    padding: "none"
  }, /*#__PURE__*/React.createElement("div", {
    style: lp.feat
  }, /*#__PURE__*/React.createElement("span", {
    style: lp.featIcon
  }, /*#__PURE__*/React.createElement(Icon, {
    name: f.icon,
    size: 20
  })), /*#__PURE__*/React.createElement("h3", {
    style: lp.featTitle
  }, f.title), /*#__PURE__*/React.createElement("p", {
    style: lp.featDesc
  }, f.desc)))))), /*#__PURE__*/React.createElement("section", {
    id: "how",
    style: {
      ...lp.section,
      paddingTop: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: lp.howCard
  }, /*#__PURE__*/React.createElement("div", {
    style: lp.howHead
  }, /*#__PURE__*/React.createElement("span", {
    className: "ipr-eyebrow",
    style: {
      color: "rgba(255,255,255,0.85)"
    }
  }, "How it works"), /*#__PURE__*/React.createElement("h2", {
    style: {
      ...lp.h2,
      color: "#fff",
      marginTop: 8
    }
  }, "Three steps. Zero slide design.")), /*#__PURE__*/React.createElement("div", {
    style: lp.steps
  }, steps.map(s => /*#__PURE__*/React.createElement("div", {
    key: s.n,
    style: lp.step
  }, /*#__PURE__*/React.createElement("span", {
    style: lp.stepNum
  }, s.n), /*#__PURE__*/React.createElement("h3", {
    style: lp.stepTitle
  }, s.t), /*#__PURE__*/React.createElement("p", {
    style: lp.stepDesc
  }, s.d)))))), /*#__PURE__*/React.createElement("section", {
    id: "pricing",
    style: lp.ctaBand
  }, /*#__PURE__*/React.createElement("h2", {
    style: lp.ctaH
  }, "Your next raise starts with a great deck"), /*#__PURE__*/React.createElement("p", {
    style: lp.ctaSub
  }, "Join thousands of founders who pitch with confidence. Free to start."), /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    size: "lg",
    iconRight: /*#__PURE__*/React.createElement(Icon, {
      name: "arrowRight",
      size: 16
    })
  }, "Generate your pitch deck")), /*#__PURE__*/React.createElement("footer", {
    style: lp.footer
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/ipreneur-logo.webp",
    alt: "iPreneur",
    style: {
      width: 110
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: lp.footNote
  }, "\xA9 2026 iPreneur \xB7 Startup Accelerator")));
}
const lp = {
  nav: {
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    padding: "18px 44px",
    borderBottom: "1px solid var(--border-subtle)",
    background: "rgba(255,255,255,0.8)",
    backdropFilter: "blur(10px)",
    position: "sticky",
    top: 0,
    zIndex: 20
  },
  navLinks: {
    display: "flex",
    gap: 28,
    position: "absolute",
    left: "50%",
    transform: "translateX(-50%)"
  },
  navLink: {
    font: "500 14px var(--font-body)",
    color: "var(--text-muted)",
    textDecoration: "none"
  },
  signin: {
    font: "600 14px var(--font-body)",
    color: "var(--text-body)",
    textDecoration: "none",
    padding: "0 12px"
  },
  hero: {
    position: "relative",
    overflow: "hidden",
    padding: "84px 24px 72px",
    textAlign: "center"
  },
  halo: {
    position: "absolute",
    inset: 0,
    background: "var(--grad-hero)",
    pointerEvents: "none"
  },
  heroInner: {
    position: "relative",
    maxWidth: 820,
    margin: "0 auto"
  },
  eyebrowPill: {
    display: "inline-flex",
    alignItems: "center",
    gap: 8,
    padding: "7px 15px",
    borderRadius: 99,
    background: "var(--surface-card)",
    border: "1px solid var(--violet-200)",
    boxShadow: "var(--shadow-xs)",
    font: "500 13px var(--font-body)",
    color: "var(--text-body)",
    marginBottom: 26
  },
  h1: {
    font: "800 60px var(--font-display)",
    lineHeight: 1.04,
    letterSpacing: "-0.035em",
    color: "var(--text-strong)"
  },
  lead: {
    maxWidth: 600,
    margin: "22px auto 0",
    font: "400 18px var(--font-body)",
    lineHeight: 1.55,
    color: "var(--text-muted)"
  },
  heroCtas: {
    display: "flex",
    gap: 12,
    justifyContent: "center",
    marginTop: 32
  },
  heroTrust: {
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    gap: 16,
    marginTop: 30,
    font: "400 13px var(--font-body)",
    color: "var(--text-muted)"
  },
  trustDivider: {
    width: 4,
    height: 4,
    borderRadius: 99,
    background: "var(--border-strong)"
  },
  logosWrap: {
    textAlign: "center",
    padding: "8px 24px 56px"
  },
  logosLabel: {
    font: "500 12px var(--font-body)",
    letterSpacing: "0.04em",
    textTransform: "uppercase",
    color: "var(--text-faint)"
  },
  logos: {
    display: "flex",
    flexWrap: "wrap",
    justifyContent: "center",
    gap: 38,
    marginTop: 22
  },
  logo: {
    font: "700 22px var(--font-display)",
    letterSpacing: "-0.02em",
    color: "var(--neutral-400)"
  },
  section: {
    maxWidth: 1080,
    margin: "0 auto",
    padding: "64px 24px"
  },
  sectionHead: {
    textAlign: "center",
    marginBottom: 40
  },
  h2: {
    font: "800 38px var(--font-display)",
    letterSpacing: "-0.03em",
    color: "var(--text-strong)",
    marginTop: 10
  },
  featGrid: {
    display: "grid",
    gridTemplateColumns: "repeat(3, 1fr)",
    gap: 18
  },
  feat: {
    padding: 28
  },
  featIcon: {
    display: "inline-flex",
    alignItems: "center",
    justifyContent: "center",
    width: 46,
    height: 46,
    borderRadius: "var(--radius-md)",
    background: "var(--violet-100)",
    color: "var(--violet-600)",
    marginBottom: 18
  },
  featTitle: {
    font: "700 19px var(--font-display)",
    color: "var(--text-strong)",
    marginBottom: 9
  },
  featDesc: {
    font: "400 14px var(--font-body)",
    lineHeight: 1.6,
    color: "var(--text-muted)"
  },
  howCard: {
    position: "relative",
    overflow: "hidden",
    borderRadius: "var(--radius-2xl)",
    background: "var(--grad-brand-vivid)",
    padding: "52px 48px",
    boxShadow: "var(--glow-brand)"
  },
  howHead: {
    textAlign: "center",
    marginBottom: 40
  },
  steps: {
    display: "grid",
    gridTemplateColumns: "repeat(3, 1fr)",
    gap: 28
  },
  step: {
    background: "rgba(255,255,255,0.12)",
    border: "1px solid rgba(255,255,255,0.18)",
    borderRadius: "var(--radius-lg)",
    padding: 24,
    backdropFilter: "blur(4px)"
  },
  stepNum: {
    font: "700 13px var(--font-mono)",
    color: "rgba(255,255,255,0.7)"
  },
  stepTitle: {
    font: "700 19px var(--font-display)",
    color: "#fff",
    margin: "12px 0 8px"
  },
  stepDesc: {
    font: "400 14px var(--font-body)",
    lineHeight: 1.6,
    color: "rgba(255,255,255,0.88)"
  },
  ctaBand: {
    textAlign: "center",
    padding: "72px 24px 80px",
    maxWidth: 680,
    margin: "0 auto"
  },
  ctaH: {
    font: "800 40px var(--font-display)",
    letterSpacing: "-0.03em",
    color: "var(--text-strong)"
  },
  ctaSub: {
    margin: "16px auto 30px",
    font: "400 17px var(--font-body)",
    color: "var(--text-muted)"
  },
  footer: {
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    padding: "28px 44px",
    borderTop: "1px solid var(--border-subtle)"
  },
  footNote: {
    font: "400 13px var(--font-body)",
    color: "var(--text-faint)"
  }
};
window.Landing = Landing;
ReactDOM.createRoot(document.getElementById("root")).render(/*#__PURE__*/React.createElement(Landing, null));
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/marketing/Landing.jsx", error: String((e && e.message) || e) }); }

__ds_ns.Avatar = __ds_scope.Avatar;

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.Card = __ds_scope.Card;

__ds_ns.Tag = __ds_scope.Tag;

__ds_ns.ProgressBar = __ds_scope.ProgressBar;

__ds_ns.StatCard = __ds_scope.StatCard;

__ds_ns.Tabs = __ds_scope.Tabs;

__ds_ns.Checkbox = __ds_scope.Checkbox;

__ds_ns.Input = __ds_scope.Input;

__ds_ns.Select = __ds_scope.Select;

__ds_ns.Switch = __ds_scope.Switch;

})();
