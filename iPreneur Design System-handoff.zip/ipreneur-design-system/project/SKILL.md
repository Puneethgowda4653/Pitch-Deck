---
name: ipreneur-design
description: Use this skill to generate well-branded interfaces and assets for iPreneur (a light, professional purple AI pitch-deck product for startups), either for production or throwaway prototypes/mocks/etc. Contains essential design guidelines, colors, type, fonts, assets, and UI kit components for prototyping.
user-invocable: true
---

Read the README.md file within this skill, and explore the other available files.
If creating visual artifacts (slides, mocks, throwaway prototypes, etc), copy assets out and create static HTML files for the user to view. If working on production code, you can copy assets and read the rules here to become an expert in designing with this brand.
If the user invokes this skill without any other guidance, ask them what they want to build or design, ask some questions, and act as an expert designer who outputs HTML artifacts _or_ production code, depending on the need.

## Quick reference
- **Brand:** iPreneur — AI pitch-deck generator / startup accelerator. Light purple, never dark. Broadly appealing, professional, confident.
- **Global CSS:** link `styles.css` (imports all tokens + fonts + base helpers).
- **Signature:** the blue→violet gradient `var(--grad-brand)` on the one primary action per view, plus a violet glow. Page bg `var(--surface-page)`, white cards, purple-tinted soft shadows.
- **Type:** Plus Jakarta Sans (display), Inter (body), JetBrains Mono (metrics).
- **Icons:** Lucide (2px outline). A ported `<Icon>` set lives in `ui_kits/app/icons.jsx`.
- **Components:** `window.IPreneurDesignSystem_e030e0` → Button, Card, Badge, Tag, Avatar, Input, Select, Switch, Checkbox, ProgressBar, StatCard, Tabs. Mount via the compiled `_ds_bundle.js`.
- **Copy voice:** sentence case, second person, action verbs, concrete numbers, no emoji.

See `readme.md` for the full content + visual + iconography guidelines, and `ui_kits/` for full-screen recreations to copy from.
