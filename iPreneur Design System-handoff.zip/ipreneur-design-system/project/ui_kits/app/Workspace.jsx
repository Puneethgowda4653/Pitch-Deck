// Workspace — generating progress + ready deck preview.
const JOB_STEPS = [
  { key: "crawling", label: "Crawling website" },
  { key: "extracting", label: "Extracting brand identity" },
  { key: "researching", label: "Researching market" },
  { key: "analyzing", label: "Analyzing investor potential" },
  { key: "generating", label: "Generating slide content" },
  { key: "rendering", label: "Rendering presentation" },
  { key: "uploading", label: "Finalizing & saving" },
];

const DECK_SLIDES = [
  { t: "Cover", k: "title" }, { t: "Problem", k: "text" }, { t: "Solution", k: "text" },
  { t: "Product", k: "image" }, { t: "Market Size", k: "chart" }, { t: "Business Model", k: "text" },
  { t: "Traction", k: "chart" }, { t: "Competition", k: "grid" }, { t: "Team", k: "team" },
  { t: "The Ask", k: "title" },
];

function Workspace({ project, status, progress, onBack }) {
  const { Button, Card, Badge, ProgressBar, Avatar } = window.IPreneurDesignSystem_e030e0;
  const Icon = window.Icon;
  const isGen = status === "generating";
  const stepIdx = Math.min(JOB_STEPS.length - 1, Math.floor((progress / 100) * JOB_STEPS.length));

  return (
    <div>
      <div style={wsStyles.topbar}>
        <div style={wsStyles.topLeft}>
          <button onClick={onBack} style={wsStyles.back}><Icon name="arrowLeft" size={15} /> Dashboard</button>
          <span style={wsStyles.divider} />
          <div>
            <div style={wsStyles.projName}>{project.name}</div>
            <div style={wsStyles.projUrl}>{project.url}</div>
          </div>
          <Badge tone={isGen ? "warning" : "success"} dot>{isGen ? "Generating" : "Ready"}</Badge>
        </div>
        <div style={{ display: "flex", gap: 10 }}>
          {!isGen && <Button variant="secondary" icon={<Icon name="edit" size={15} />}>Edit Deck</Button>}
          {!isGen && <Button variant="primary" icon={<Icon name="download" size={15} />}>Export PPTX</Button>}
        </div>
      </div>

      <div style={wsStyles.body}>
        <aside style={wsStyles.aside}>
          <Card padding="none">
            <div style={wsStyles.brandHead}>
              <Avatar name={project.company} square size="lg" src={project.logo} />
              <div style={{ minWidth: 0 }}>
                <div style={wsStyles.brandName}>{project.company}</div>
                <div style={wsStyles.brandUrl}>{project.url}</div>
              </div>
            </div>
            <div style={wsStyles.brandBody}>
              <div style={wsStyles.metaRow}><span style={wsStyles.metaK}>Industry</span><span style={wsStyles.metaV}>{project.industry}</span></div>
              <div style={wsStyles.metaRow}><span style={wsStyles.metaK}>Stage</span><span style={wsStyles.metaV}>Series A</span></div>
              <div style={wsStyles.metaRow}><span style={wsStyles.metaK}>Ask</span><span style={wsStyles.metaV}>$1.5M</span></div>
              <div style={{ ...wsStyles.metaRow, borderBottom: 0 }}><span style={wsStyles.metaK}>Palette</span>
                <span style={{ display: "flex", gap: 5 }}>
                  <span style={{ ...wsStyles.swatch, background: project.colors[0] }} />
                  <span style={{ ...wsStyles.swatch, background: project.colors[1] }} />
                </span>
              </div>
            </div>
          </Card>
        </aside>

        <main style={{ minWidth: 0 }}>
          {isGen ? (
            <Card>
              <div style={wsStyles.genHead}>
                <div className="ipr-mark" style={{ width: 38, height: 38, borderRadius: "var(--radius-md)" }}>
                  <Icon name="sparkles" size={18} />
                </div>
                <div>
                  <div style={wsStyles.genTitle}>AI analysis in progress</div>
                  <div style={wsStyles.genSub}>{JOB_STEPS[stepIdx].label}…</div>
                </div>
              </div>
              <div style={{ margin: "22px 0 26px" }}>
                <ProgressBar value={progress} label="Overall progress" showValue animated />
              </div>
              <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
                {JOB_STEPS.map((s, i) => {
                  const done = i < stepIdx, cur = i === stepIdx;
                  return (
                    <div key={s.key} style={{ ...wsStyles.step, ...(cur ? wsStyles.stepCur : {}), opacity: i > stepIdx ? 0.4 : 1 }}>
                      <span style={{ ...wsStyles.stepIcon, ...(done ? wsStyles.stepDone : cur ? wsStyles.stepCurIcon : wsStyles.stepPend) }}>
                        {done ? <Icon name="check" size={13} /> : <span style={{ font: "600 11px var(--font-mono)" }}>{i + 1}</span>}
                      </span>
                      <span style={{ flex: 1, font: cur ? "600 14px var(--font-body)" : "500 14px var(--font-body)", color: cur ? "var(--text-strong)" : "var(--text-muted)" }}>{s.label}</span>
                      {done && <span style={wsStyles.stepStatus}>Done</span>}
                      {cur && <span style={{ font: "500 12px var(--font-mono)", color: "var(--text-brand)" }}>Working…</span>}
                    </div>
                  );
                })}
              </div>
            </Card>
          ) : (
            <div>
              <div style={wsStyles.previewHead}>
                <h2 style={wsStyles.previewTitle}>Generated deck</h2>
                <span style={wsStyles.previewMeta}>{DECK_SLIDES.length} slides · 16:9 · PPTX</span>
              </div>
              <div style={wsStyles.slideGrid}>
                {DECK_SLIDES.map((s, i) => <SlideThumb key={i} index={i} slide={s} project={project} />)}
              </div>
            </div>
          )}
        </main>
      </div>
    </div>
  );
}

function SlideThumb({ index, slide, project }) {
  const isCover = slide.k === "title";
  return (
    <div style={wsStyles.slide}>
      <div style={{ ...wsStyles.slideCanvas, ...(isCover ? { background: "var(--grad-brand)" } : {}) }}>
        {isCover ? (
          <div style={wsStyles.coverInner}>
            <div style={wsStyles.coverDot} />
            <div style={wsStyles.coverTitle}>{project.company}</div>
            <div style={wsStyles.coverSub}>{slide.t === "Cover" ? "Series A · 2026" : "$1.5M Round"}</div>
          </div>
        ) : (
          <div style={wsStyles.slideInner}>
            <div style={wsStyles.slideBar} />
            {slide.k === "chart" && <div style={wsStyles.chart}>{[40, 62, 48, 78, 95].map((h, j) => <span key={j} style={{ ...wsStyles.chartBar, height: h + "%" }} />)}</div>}
            {slide.k === "grid" && <div style={wsStyles.miniGrid}>{[0,1,2,3].map((j) => <span key={j} style={wsStyles.miniCell} />)}</div>}
            {slide.k === "team" && <div style={wsStyles.team}>{[0,1,2].map((j) => <span key={j} style={wsStyles.teamDot} />)}</div>}
            {slide.k === "image" && <div style={wsStyles.imgBlock} />}
            {(slide.k === "text") && <div style={wsStyles.lines}>{[100,82,90,68].map((w,j)=><span key={j} style={{...wsStyles.line, width: w+"%"}}/>)}</div>}
          </div>
        )}
      </div>
      <div style={wsStyles.slideLabel}><span style={wsStyles.slideNum}>{String(index + 1).padStart(2, "0")}</span> {slide.t}</div>
    </div>
  );
}

const wsStyles = {
  topbar: { position: "sticky", top: 0, zIndex: 10, display: "flex", alignItems: "center", justifyContent: "space-between", gap: 16, padding: "14px 28px", background: "rgba(255,255,255,0.82)", backdropFilter: "blur(10px)", borderBottom: "1px solid var(--border-subtle)" },
  topLeft: { display: "flex", alignItems: "center", gap: 16, minWidth: 0 },
  back: { display: "inline-flex", alignItems: "center", gap: 6, border: 0, background: "none", cursor: "pointer", font: "500 13px var(--font-body)", color: "var(--text-muted)" },
  divider: { width: 1, height: 18, background: "var(--border-default)" },
  projName: { font: "700 14px var(--font-display)", color: "var(--text-strong)" },
  projUrl: { font: "400 12px var(--font-body)", color: "var(--text-faint)" },
  body: { display: "grid", gridTemplateColumns: "300px 1fr", gap: 26, maxWidth: 1180, margin: "0 auto", padding: "28px 28px 50px" },
  aside: {},
  brandHead: { display: "flex", alignItems: "center", gap: 12, padding: 18, borderBottom: "1px solid var(--border-subtle)" },
  brandName: { font: "700 15px var(--font-display)", color: "var(--text-strong)" },
  brandUrl: { font: "400 12px var(--font-body)", color: "var(--text-faint)" },
  brandBody: { padding: "6px 18px 12px" },
  metaRow: { display: "flex", alignItems: "center", justifyContent: "space-between", padding: "11px 0", borderBottom: "1px solid var(--border-subtle)" },
  metaK: { font: "500 12px var(--font-body)", color: "var(--text-muted)" },
  metaV: { font: "600 13px var(--font-body)", color: "var(--text-strong)" },
  swatch: { width: 18, height: 18, borderRadius: 6, border: "1.5px solid #fff", boxShadow: "var(--shadow-xs)" },
  genHead: { display: "flex", alignItems: "center", gap: 13 },
  genTitle: { font: "700 17px var(--font-display)", color: "var(--text-strong)" },
  genSub: { marginTop: 3, font: "400 13px var(--font-body)", color: "var(--text-muted)" },
  step: { display: "flex", alignItems: "center", gap: 14, padding: "10px 13px", borderRadius: "var(--radius-md)", border: "1px solid transparent", transition: "var(--transition)" },
  stepCur: { background: "var(--surface-sunken)", borderColor: "var(--border-subtle)" },
  stepIcon: { width: 26, height: 26, borderRadius: 99, display: "inline-flex", alignItems: "center", justifyContent: "center", flexShrink: 0 },
  stepDone: { background: "var(--success-surface)", color: "var(--green-600)" },
  stepCurIcon: { background: "var(--grad-brand)", color: "#fff" },
  stepPend: { background: "var(--surface-sunken)", color: "var(--text-faint)", border: "1px solid var(--border-subtle)" },
  stepStatus: { font: "500 12px var(--font-body)", color: "var(--green-600)" },
  previewHead: { display: "flex", alignItems: "baseline", justifyContent: "space-between", marginBottom: 18 },
  previewTitle: { font: "800 22px var(--font-display)", letterSpacing: "-0.02em", color: "var(--text-strong)" },
  previewMeta: { font: "500 12px var(--font-mono)", color: "var(--text-muted)" },
  slideGrid: { display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 16 },
  slide: { display: "flex", flexDirection: "column", gap: 8 },
  slideCanvas: { aspectRatio: "16/9", borderRadius: "var(--radius-md)", background: "var(--surface-card)", border: "1px solid var(--border-subtle)", boxShadow: "var(--shadow-sm)", overflow: "hidden", padding: 14 },
  slideInner: { height: "100%", display: "flex", flexDirection: "column", gap: 9 },
  slideBar: { width: "44%", height: 7, borderRadius: 99, background: "var(--violet-200)" },
  lines: { display: "flex", flexDirection: "column", gap: 6, marginTop: 2 },
  line: { height: 5, borderRadius: 99, background: "var(--neutral-200)" },
  chart: { flex: 1, display: "flex", alignItems: "flex-end", gap: 8, paddingTop: 6 },
  chartBar: { flex: 1, borderRadius: "3px 3px 0 0", background: "var(--grad-brand)" },
  miniGrid: { flex: 1, display: "grid", gridTemplateColumns: "1fr 1fr", gap: 7, paddingTop: 4 },
  miniCell: { borderRadius: 6, background: "var(--surface-sunken)", border: "1px solid var(--border-subtle)" },
  team: { flex: 1, display: "flex", alignItems: "center", gap: 10 },
  teamDot: { width: 30, height: 30, borderRadius: 99, background: "var(--violet-100)", border: "1.5px solid var(--violet-200)" },
  imgBlock: { flex: 1, borderRadius: 8, background: "var(--grad-brand-soft)", border: "1px solid var(--violet-100)" },
  coverInner: { height: "100%", display: "flex", flexDirection: "column", justifyContent: "flex-end", gap: 6, color: "#fff" },
  coverDot: { width: 22, height: 22, borderRadius: 7, background: "rgba(255,255,255,0.9)", marginBottom: "auto" },
  coverTitle: { font: "800 17px var(--font-display)", letterSpacing: "-0.02em" },
  coverSub: { font: "500 12px var(--font-body)", opacity: 0.85 },
  slideLabel: { display: "flex", alignItems: "center", gap: 8, font: "500 12px var(--font-body)", color: "var(--text-muted)" },
  slideNum: { font: "600 11px var(--font-mono)", color: "var(--text-faint)" },
};

window.Workspace = Workspace;
