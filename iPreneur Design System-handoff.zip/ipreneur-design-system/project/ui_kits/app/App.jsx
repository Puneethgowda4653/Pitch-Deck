// Interactive shell — state machine wiring all screens together.
const SEED_PROJECTS = [
  { id: 1, name: "Linear — Series B", company: "Linear", url: "linear.app", industry: "Dev Tools", status: "ready", colors: ["#5E6AD2", "#26282F"], updated: "2 hours ago", logo: null },
  { id: 2, name: "Ramp Growth Round", company: "Ramp", url: "ramp.com", industry: "Fintech", status: "ready", colors: ["#E8FE52", "#1A1A1A"], updated: "yesterday", logo: null },
  { id: 3, name: "Notion Series C", company: "Notion", url: "notion.so", industry: "Productivity", status: "generating", colors: ["#000000", "#F7F6F3"], updated: "just now", logo: null },
  { id: 4, name: "Figma Pitch", company: "Figma", url: "figma.com", industry: "Design", status: "draft", colors: ["#A259FF", "#F24E1E"], updated: "3 days ago", logo: null },
  { id: 5, name: "Vercel Seed", company: "Vercel", url: "vercel.com", industry: "Infrastructure", status: "ready", colors: ["#000000", "#0070F3"], updated: "5 days ago", logo: null },
  { id: 6, name: "Retool Series A", company: "Retool", url: "retool.com", industry: "Low-code", status: "draft", colors: ["#3B5BFE", "#1E1E1E"], updated: "1 week ago", logo: null },
];

const USER = { name: "Aanya Rao", plan: "Pro plan" };

function App() {
  const [authed, setAuthed] = React.useState(false);
  const [screen, setScreen] = React.useState("dashboard");
  const [active, setActive] = React.useState(null);
  const [status, setStatus] = React.useState("ready");
  const [progress, setProgress] = React.useState(0);
  const timer = React.useRef(null);

  function openProject(p) {
    setActive(p);
    if (p.status === "generating") { startGen(); }
    else { setStatus("ready"); }
    setScreen("workspace");
  }

  function startGen() {
    setStatus("generating");
    setProgress(6);
    clearInterval(timer.current);
    timer.current = setInterval(() => {
      setProgress((v) => {
        if (v >= 100) { clearInterval(timer.current); setStatus("ready"); return 100; }
        return Math.min(100, v + 3.2);
      });
    }, 180);
  }

  function createDeck() {
    const p = { id: 99, name: "Linear — Series B", company: "Linear", url: "linear.app", industry: "Dev Tools", status: "generating", colors: ["#5E6AD2", "#26282F"], updated: "just now", logo: null };
    setActive(p);
    startGen();
    setScreen("workspace");
  }

  React.useEffect(() => () => clearInterval(timer.current), []);

  if (!authed) return <window.Login onLogin={() => { setAuthed(true); setScreen("dashboard"); }} />;

  return (
    <div style={{ display: "flex", height: "100%", background: "var(--surface-page)" }}>
      <window.Sidebar
        active={screen === "workspace" ? "dashboard" : screen}
        onNavigate={(k) => { setScreen(k === "new" ? "new" : k === "dashboard" ? "dashboard" : k); }}
        onLogout={() => setAuthed(false)}
        user={USER}
      />
      <main style={{ flex: 1, overflowY: "auto", position: "relative" }}>
        {screen === "dashboard" && (
          <window.Dashboard user={USER} projects={SEED_PROJECTS}
            onOpen={openProject} onNew={() => setScreen("new")} />
        )}
        {screen === "new" && (
          <window.NewDeck onBack={() => setScreen("dashboard")} onCreate={createDeck} />
        )}
        {screen === "workspace" && active && (
          <window.Workspace project={active} status={status} progress={progress}
            onBack={() => setScreen("dashboard")} />
        )}
        {(screen === "settings" || screen === "billing") && (
          <Placeholder title={screen === "settings" ? "Settings" : "Billing"} onBack={() => setScreen("dashboard")} />
        )}
      </main>
    </div>
  );
}

function Placeholder({ title, onBack }) {
  const { Button } = window.IPreneurDesignSystem_e030e0;
  const Icon = window.Icon;
  return (
    <div style={{ maxWidth: 1180, margin: "0 auto", padding: "34px 38px" }}>
      <h1 style={{ font: "800 32px var(--font-display)", letterSpacing: "-0.03em", color: "var(--text-strong)", marginBottom: 8 }}>{title}</h1>
      <p style={{ font: "400 14px var(--font-body)", color: "var(--text-muted)", marginBottom: 22 }}>This view isn't part of the kit preview.</p>
      <Button variant="secondary" icon={<Icon name="arrowLeft" size={15} />} onClick={onBack}>Back to dashboard</Button>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
