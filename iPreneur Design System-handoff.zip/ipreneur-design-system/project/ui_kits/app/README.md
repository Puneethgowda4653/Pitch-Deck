# iPreneur App — UI Kit

Interactive recreation of the iPreneur product: an AI pitch-deck generator for startups. Light-purple theme built on the iPreneur design system.

## Flow
`index.html` is a click-through:
1. **Login** → sign in (any credentials)
2. **Dashboard** → greeting, stat tiles, filterable project grid
3. **New Deck** → company-URL form (website, name, funding stage, model, generate-immediately toggle)
4. **Workspace (generating)** → live AI-analysis progress through 7 job steps
5. **Workspace (ready)** → generated 10-slide deck preview grid with Export PPTX

Open a `generating` project from the dashboard, or create a new deck, to watch the progress animation run to completion and flip to the ready state.

## Files
- `index.html` — entry; loads the DS bundle + all screen scripts
- `icons.jsx` — lucide-style icon set (`window.Icon`), matches the product's `lucide-react`
- `Sidebar.jsx` — logo, nav, user card
- `Login.jsx` · `Dashboard.jsx` · `NewDeck.jsx` · `Workspace.jsx` — screens
- `App.jsx` — state machine wiring the flow

## Composition
Screens compose design-system primitives from `window.IPreneurDesignSystem_e030e0` — `Button`, `Card`, `Badge`, `Input`, `Select`, `Switch`, `ProgressBar`, `StatCard`, `Tabs`, `Avatar` — never re-implementing them. Layout-specific styling lives in per-file `*Styles` objects using the token CSS variables.

Source of truth: the attached `frontend/` codebase (React + Tailwind + lucide + framer-motion). The original ships a **dark** theme; this kit is the **light-purple** redesign requested by the brand owner, keeping the same product structure, copy, and component vocabulary.
