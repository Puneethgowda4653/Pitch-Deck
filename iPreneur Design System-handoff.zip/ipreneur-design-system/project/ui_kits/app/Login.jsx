// Login screen.
function Login({ onLogin }) {
  const { Button, Input } = window.IPreneurDesignSystem_e030e0;
  const Icon = window.Icon;
  return (
    <div style={loginStyles.wrap}>
      <div style={loginStyles.halo} />
      <div style={loginStyles.card}>
        <img src="../../assets/ipreneur-logo.webp" alt="iPreneur" style={{ width: 140, margin: "0 auto 26px", display: "block" }} />
        <h1 style={loginStyles.h1}>Welcome back</h1>
        <p style={loginStyles.sub}>Sign in to your iPreneur account</p>
        <div style={loginStyles.form}>
          <Input label="Email" defaultValue="aanya@foundry.vc" placeholder="you@company.com" />
          <Input label="Password" type="password" defaultValue="password" placeholder="••••••••" />
          <Button variant="primary" size="lg" fullWidth onClick={onLogin}
            iconRight={<Icon name="arrowRight" size={16} />}>Sign in</Button>
        </div>
        <p style={loginStyles.foot}>Don't have an account? <a href="#" onClick={(e)=>{e.preventDefault();onLogin();}} style={{ color: "var(--text-link)", fontWeight: 600 }}>Sign up</a></p>
      </div>
    </div>
  );
}

const loginStyles = {
  wrap: { minHeight: "100%", display: "flex", alignItems: "center", justifyContent: "center", padding: 24, position: "relative", overflow: "hidden" },
  halo: { position: "absolute", inset: 0, background: "var(--grad-hero)", pointerEvents: "none" },
  card: { position: "relative", width: "100%", maxWidth: 400, background: "var(--surface-card)", border: "1px solid var(--border-subtle)", borderRadius: "var(--radius-xl)", boxShadow: "var(--shadow-lg)", padding: "38px 36px" },
  h1: { font: "800 26px var(--font-display)", letterSpacing: "-0.03em", color: "var(--text-strong)", textAlign: "center" },
  sub: { marginTop: 7, marginBottom: 26, font: "400 14px var(--font-body)", color: "var(--text-muted)", textAlign: "center" },
  form: { display: "flex", flexDirection: "column", gap: 16 },
  foot: { marginTop: 22, textAlign: "center", font: "400 13px var(--font-body)", color: "var(--text-muted)" },
};

window.Login = Login;
