// New Deck — create form.
function NewDeck({ onBack, onCreate }) {
  const { Button, Card, Input, Select, Switch } = window.IPreneurDesignSystem_e030e0;
  const Icon = window.Icon;
  const [url, setUrl] = React.useState("https://linear.app");
  const [name, setName] = React.useState("Linear — Series B");
  const [stage, setStage] = React.useState("series_a");
  const [auto, setAuto] = React.useState(true);

  const examples = ["stripe.com", "notion.so", "figma.com", "ramp.com"];

  return (
    <div style={ndStyles.page}>
      <button onClick={onBack} style={ndStyles.back}>
        <Icon name="arrowLeft" size={15} /> Dashboard
      </button>

      <div style={ndStyles.head}>
        <div className="ipr-mark" style={ndStyles.mark}>
          <Icon name="sparkles" size={26} />
        </div>
        <h1 style={ndStyles.h1}>Create your pitch deck</h1>
        <p style={ndStyles.sub}>Drop in a company URL. Our AI does the rest.</p>
      </div>

      <Card padding="none" style={{ overflow: "hidden" }}>
        <div style={ndStyles.form}>
          <div>
            <Input label="Company website" icon={<Icon name="globe" size={16} />}
              value={url} onChange={(e) => setUrl(e.target.value)} placeholder="https://yourcompany.com" />
            <div style={ndStyles.examples}>
              {examples.map((e) => (
                <button key={e} style={ndStyles.exBtn} onClick={() => setUrl("https://" + e)}>{e}</button>
              ))}
            </div>
          </div>

          <Input label="Project name" value={name} onChange={(e) => setName(e.target.value)} placeholder="e.g. Series A deck" />

          <div style={ndStyles.twoCol}>
            <Select label="Funding stage" value={stage} onChange={(e) => setStage(e.target.value)}
              options={[
                { value: "pre_seed", label: "Pre-seed" },
                { value: "seed", label: "Seed" },
                { value: "series_a", label: "Series A" },
                { value: "series_b", label: "Series B" },
                { value: "growth", label: "Growth" },
              ]} />
            <Select label="Business model" placeholder="AI will detect"
              options={["SaaS", "Marketplace", "Fintech", "Ecommerce", "Hardware"]} />
          </div>

          <div style={ndStyles.toggleRow}>
            <div>
              <div style={ndStyles.toggleTitle}>Generate immediately</div>
              <div style={ndStyles.toggleSub}>Start AI analysis right after creating</div>
            </div>
            <Switch checked={auto} onChange={setAuto} />
          </div>

          <Button variant="primary" size="lg" fullWidth onClick={onCreate}
            iconRight={<Icon name="arrowRight" size={16} />}>Create Deck</Button>
        </div>
      </Card>

      <p style={ndStyles.trust}>Analysis takes ~2 minutes · PPTX output · Fully editable</p>
    </div>
  );
}

const ndStyles = {
  page: { maxWidth: 560, margin: "0 auto", padding: "30px 24px 60px", position: "relative" },
  back: { display: "inline-flex", alignItems: "center", gap: 6, border: 0, background: "none", cursor: "pointer", font: "500 13px var(--font-body)", color: "var(--text-muted)", marginBottom: 26 },
  head: { textAlign: "center", marginBottom: 26 },
  mark: { width: 56, height: 56, margin: "0 auto 16px" },
  h1: { font: "800 28px var(--font-display)", letterSpacing: "-0.03em", color: "var(--text-strong)" },
  sub: { marginTop: 7, font: "400 15px var(--font-body)", color: "var(--text-muted)" },
  form: { padding: 26, display: "flex", flexDirection: "column", gap: 18 },
  examples: { display: "flex", flexWrap: "wrap", gap: 12, marginTop: 9 },
  exBtn: { border: 0, background: "none", cursor: "pointer", font: "500 12px var(--font-body)", color: "var(--text-faint)" },
  twoCol: { display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14 },
  toggleRow: { display: "flex", alignItems: "center", justifyContent: "space-between", gap: 14, padding: "13px 16px", background: "var(--surface-sunken)", borderRadius: "var(--radius-md)" },
  toggleTitle: { font: "600 13px var(--font-body)", color: "var(--text-strong)" },
  toggleSub: { marginTop: 3, font: "400 12px var(--font-body)", color: "var(--text-muted)" },
  trust: { textAlign: "center", marginTop: 18, font: "400 12px var(--font-body)", color: "var(--text-faint)" },
};

window.NewDeck = NewDeck;
