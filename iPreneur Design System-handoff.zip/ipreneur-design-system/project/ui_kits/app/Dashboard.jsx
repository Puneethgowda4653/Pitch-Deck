// Dashboard — greeting, stats, project grid.
function Dashboard({ user, projects, onOpen, onNew }) {
  const { Button, Card, Badge, StatCard, Tabs } = window.IPreneurDesignSystem_e030e0;
  const Icon = window.Icon;
  const [tab, setTab] = React.useState("all");

  const filtered = projects.filter((p) =>
    tab === "all" ? true : tab === "ready" ? p.status === "ready" : p.status === "draft" || p.status === "generating"
  );
  const readyCount = projects.filter((p) => p.status === "ready").length;
  const activeCount = projects.filter((p) => p.status === "generating").length;

  const statusTone = { ready: "success", generating: "warning", draft: "neutral", error: "danger" };
  const statusLabel = { ready: "Ready", generating: "Generating", draft: "Draft", error: "Error" };

  return (
    <div style={dashStyles.page}>
      <div style={dashStyles.header}>
        <div>
          <h1 style={dashStyles.h1}>
            Good afternoon, <span className="ipr-gradient-text">{user.name.split(" ")[0]}</span>
          </h1>
          <p style={dashStyles.sub}>You have {projects.length} pitch decks in your workspace</p>
        </div>
        <Button variant="primary" size="lg" icon={<Icon name="plus" size={16} />} onClick={onNew}>New Deck</Button>
      </div>

      <div style={dashStyles.stats}>
        <StatCard icon={<Icon name="fileText" />} value={String(projects.length)} label="Total decks" />
        <StatCard gradientIcon icon={<Icon name="check" />} value={String(readyCount)} label="Ready to pitch" />
        <StatCard icon={<Icon name="sparkles" />} value={String(activeCount)} label="In progress" />
        <StatCard icon={<Icon name="trendingUp" />} value="$4.6M" label="Tracked ARR" />
      </div>

      <div style={dashStyles.toolbar}>
        <Tabs value={tab} onChange={setTab} tabs={[
          { value: "all", label: "All", count: projects.length },
          { value: "ready", label: "Ready", count: readyCount },
          { value: "drafts", label: "Drafts", count: projects.length - readyCount },
        ]} />
      </div>

      <div style={dashStyles.grid}>
        {filtered.map((p) => (
          <Card key={p.id} interactive padding="none" onClick={() => onOpen(p)}>
            <div style={dashStyles.cardInner}>
              <div style={dashStyles.cardTop}>
                <div style={{ minWidth: 0 }}>
                  <div style={dashStyles.cardName}>{p.name}</div>
                  <div style={dashStyles.cardUrl}>
                    <Icon name="globe" size={12} /> {p.url}
                  </div>
                </div>
                <Badge tone={statusTone[p.status]} dot>{statusLabel[p.status]}</Badge>
              </div>
              <div style={dashStyles.swatches}>
                <span style={{ ...dashStyles.dot, background: p.colors[0] }} />
                <span style={{ ...dashStyles.dot, background: p.colors[1] }} />
                <span style={dashStyles.industry}>{p.industry}</span>
              </div>
              <div style={dashStyles.cardFoot}>
                <span style={dashStyles.time}><Icon name="clock" size={12} /> {p.updated}</span>
                <Icon name="chevronRight" size={15} style={{ color: "var(--text-faint)" }} />
              </div>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}

const dashStyles = {
  page: { padding: "34px 38px 48px", maxWidth: 1180, margin: "0 auto" },
  header: { display: "flex", alignItems: "flex-start", justifyContent: "space-between", gap: 20, marginBottom: 26 },
  h1: { font: "800 32px var(--font-display)", letterSpacing: "-0.03em", color: "var(--text-strong)" },
  sub: { marginTop: 6, font: "400 14px var(--font-body)", color: "var(--text-muted)" },
  stats: { display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 14, marginBottom: 26 },
  toolbar: { marginBottom: 18 },
  grid: { display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 16 },
  cardInner: { padding: 18, display: "flex", flexDirection: "column", gap: 14 },
  cardTop: { display: "flex", alignItems: "flex-start", justifyContent: "space-between", gap: 10 },
  cardName: { font: "700 15px var(--font-display)", color: "var(--text-strong)", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" },
  cardUrl: { display: "flex", alignItems: "center", gap: 5, marginTop: 5, font: "400 12px var(--font-body)", color: "var(--text-faint)" },
  swatches: { display: "flex", alignItems: "center", gap: 7 },
  dot: { width: 18, height: 18, borderRadius: 99, border: "1.5px solid #fff", boxShadow: "var(--shadow-xs)" },
  industry: { marginLeft: 4, font: "500 11px var(--font-body)", color: "var(--text-muted)", background: "var(--surface-sunken)", padding: "3px 9px", borderRadius: 99 },
  cardFoot: { display: "flex", alignItems: "center", justifyContent: "space-between", paddingTop: 12, borderTop: "1px solid var(--border-subtle)" },
  time: { display: "flex", alignItems: "center", gap: 5, font: "400 12px var(--font-body)", color: "var(--text-faint)" },
};

window.Dashboard = Dashboard;
