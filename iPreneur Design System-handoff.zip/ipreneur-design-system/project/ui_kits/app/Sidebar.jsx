// iPreneur app sidebar — logo, nav, user card.
function Sidebar({ active, onNavigate, onLogout, user }) {
  const { Avatar } = window.IPreneurDesignSystem_e030e0;
  const Icon = window.Icon;
  const items = [
    { key: "dashboard", icon: "dashboard", label: "Dashboard" },
    { key: "new", icon: "plus", label: "New Deck" },
    { key: "settings", icon: "settings", label: "Settings" },
    { key: "billing", icon: "billing", label: "Billing" },
  ];

  return (
    <aside style={styles.aside}>
      <div style={styles.logoWrap}>
        <img src="../../assets/ipreneur-logo.webp" alt="iPreneur" style={{ width: 124 }} />
      </div>

      <nav style={styles.nav}>
        {items.map((it) => {
          const on = active === it.key;
          return (
            <button key={it.key} onClick={() => onNavigate(it.key)}
              style={{ ...styles.navItem, ...(on ? styles.navItemOn : {}) }}>
              <Icon name={it.icon} size={18} />
              <span style={{ flex: 1, textAlign: "left" }}>{it.label}</span>
              {on && <span style={styles.navDot} />}
            </button>
          );
        })}
      </nav>

      <div style={styles.userCard}>
        <Avatar name={user.name} size="sm" />
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={styles.userName}>{user.name}</div>
          <div style={styles.userRole}>{user.plan}</div>
        </div>
        <button onClick={onLogout} title="Sign out" style={styles.logoutBtn}>
          <Icon name="logout" size={15} />
        </button>
      </div>
    </aside>
  );
}

const styles = {
  aside: {
    width: 232, flexShrink: 0, display: "flex", flexDirection: "column",
    background: "var(--surface-card)", borderRight: "1px solid var(--border-subtle)",
  },
  logoWrap: { padding: "22px 22px 18px", borderBottom: "1px solid var(--border-subtle)" },
  nav: { flex: 1, padding: "16px 12px", display: "flex", flexDirection: "column", gap: 3 },
  navItem: {
    display: "flex", alignItems: "center", gap: 12, padding: "10px 12px",
    borderRadius: "var(--radius-md)", border: "1px solid transparent", background: "transparent",
    color: "var(--text-muted)", font: "600 14px var(--font-body)", cursor: "pointer",
    transition: "var(--transition)", width: "100%",
  },
  navItemOn: {
    background: "var(--violet-50)", color: "var(--text-brand)",
    borderColor: "var(--violet-200)",
  },
  navDot: { width: 5, height: 16, borderRadius: 99, background: "var(--grad-brand)" },
  userCard: {
    margin: 12, padding: "10px 11px", display: "flex", alignItems: "center", gap: 11,
    borderRadius: "var(--radius-md)", background: "var(--surface-sunken)",
  },
  userName: { font: "600 12px var(--font-body)", color: "var(--text-strong)", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" },
  userRole: { font: "500 11px var(--font-body)", color: "var(--text-muted)" },
  logoutBtn: { border: 0, background: "none", color: "var(--text-faint)", cursor: "pointer", display: "inline-flex", padding: 4 },
};

window.Sidebar = Sidebar;
