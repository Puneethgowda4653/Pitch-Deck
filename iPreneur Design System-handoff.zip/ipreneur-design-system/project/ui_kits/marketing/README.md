# iPreneur Marketing — UI Kit

Light-theme marketing landing page for iPreneur, recreated from the attached `frontend/src/pages/LandingPage.tsx`.

## Sections
- Sticky nav (logo, links, sign-in + Get started)
- Hero — eyebrow pill, gradient headline, lead, dual CTA, trust row
- Logo wall (founders raising at…)
- Feature trio — market research / AI narrative / export
- "How it works" gradient panel — 3 steps
- CTA band + footer

## Files
- `index.html` — entry; loads the DS bundle, shared `../app/icons.jsx`, and `Landing.jsx`
- `Landing.jsx` — the full page; composes `Button`, `Badge`, `Card` from `window.IPreneurDesignSystem_e030e0`

The original landing page copy ("Turn your idea into an investor-ready pitch deck", the three feature cards) is preserved; the dark palette is reskinned to the light-purple system.
