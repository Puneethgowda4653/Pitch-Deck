// iPreneur marketing landing page — light theme.
function Landing() {
  const { Button, Badge, Card } = window.IPreneurDesignSystem_e030e0;
  const Icon = window.Icon;

  const features = [
    { icon: "target", title: "Market research, automated", desc: "iPreneur researches your industry, competitors, and market size — no spreadsheets, no guesswork." },
    { icon: "sparkles", title: "AI-crafted narrative", desc: "Claude writes a compelling story for every slide: problem, solution, traction, and the ask." },
    { icon: "barChart", title: "Export & share", desc: "Download a polished, fully-editable PPTX or PDF — ready to send to investors in one click." },
  ];
  const steps = [
    { n: "01", t: "Drop a URL", d: "Paste your company website. That's the only input we need to start." },
    { n: "02", t: "AI analyzes", d: "We crawl your site, extract your brand, and research your market in ~2 minutes." },
    { n: "03", t: "Get your deck", d: "A 10-slide, investor-ready pitch deck — on-brand and editable." },
  ];
  const logos = ["Linear", "Ramp", "Notion", "Figma", "Vercel", "Retool"];

  return (
    <div>
      {/* Nav */}
      <nav style={lp.nav}>
        <img src="../../assets/ipreneur-logo.webp" alt="iPreneur" style={{ width: 122 }} />
        <div style={lp.navLinks}>
          <a href="#features" style={lp.navLink}>Features</a>
          <a href="#how" style={lp.navLink}>How it works</a>
          <a href="#pricing" style={lp.navLink}>Pricing</a>
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <a href="#" style={lp.signin}>Sign in</a>
          <Button variant="primary" icon={<Icon name="sparkles" size={15} />}>Get started</Button>
        </div>
      </nav>

      {/* Hero */}
      <header style={lp.hero}>
        <div style={lp.halo} />
        <div style={lp.heroInner}>
          <div style={lp.eyebrowPill}>
            <Icon name="zap" size={13} style={{ color: "var(--violet-600)" }} />
            <span>AI-powered pitch decks · Backed by a startup accelerator</span>
          </div>
          <h1 style={lp.h1}>
            Turn your idea into an<br /><span className="ipr-gradient-text">investor-ready</span> pitch deck
          </h1>
          <p style={lp.lead}>
            iPreneur crawls your company website, researches your market, and generates a
            professional pitch deck tailored for investors — in under five minutes.
          </p>
          <div style={lp.heroCtas}>
            <Button variant="primary" size="lg" iconRight={<Icon name="arrowRight" size={16} />}>Generate your deck</Button>
            <Button variant="secondary" size="lg" icon={<Icon name="play" size={14} />}>Watch demo</Button>
          </div>
          <div style={lp.heroTrust}>
            <span><b style={{ color: "var(--text-strong)" }}>12,000+</b> decks generated</span>
            <span style={lp.trustDivider} />
            <span><b style={{ color: "var(--text-strong)" }}>~2 min</b> average build</span>
            <span style={lp.trustDivider} />
            <span>PPTX &amp; PDF export</span>
          </div>
        </div>
      </header>

      {/* Logos */}
      <section style={lp.logosWrap}>
        <span style={lp.logosLabel}>Pitch decks built for founders raising at</span>
        <div style={lp.logos}>
          {logos.map((l) => <span key={l} style={lp.logo}>{l}</span>)}
        </div>
      </section>

      {/* Features */}
      <section id="features" style={lp.section}>
        <div style={lp.sectionHead}>
          <span className="ipr-eyebrow">Everything in one flow</span>
          <h2 style={lp.h2}>From URL to investor deck, automatically</h2>
        </div>
        <div style={lp.featGrid}>
          {features.map((f) => (
            <Card key={f.title} padding="none">
              <div style={lp.feat}>
                <span style={lp.featIcon}><Icon name={f.icon} size={20} /></span>
                <h3 style={lp.featTitle}>{f.title}</h3>
                <p style={lp.featDesc}>{f.desc}</p>
              </div>
            </Card>
          ))}
        </div>
      </section>

      {/* How it works */}
      <section id="how" style={{ ...lp.section, paddingTop: 0 }}>
        <div style={lp.howCard}>
          <div style={lp.howHead}>
            <span className="ipr-eyebrow" style={{ color: "rgba(255,255,255,0.85)" }}>How it works</span>
            <h2 style={{ ...lp.h2, color: "#fff", marginTop: 8 }}>Three steps. Zero slide design.</h2>
          </div>
          <div style={lp.steps}>
            {steps.map((s) => (
              <div key={s.n} style={lp.step}>
                <span style={lp.stepNum}>{s.n}</span>
                <h3 style={lp.stepTitle}>{s.t}</h3>
                <p style={lp.stepDesc}>{s.d}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA band */}
      <section id="pricing" style={lp.ctaBand}>
        <h2 style={lp.ctaH}>Your next raise starts with a great deck</h2>
        <p style={lp.ctaSub}>Join thousands of founders who pitch with confidence. Free to start.</p>
        <Button variant="primary" size="lg" iconRight={<Icon name="arrowRight" size={16} />}>Generate your pitch deck</Button>
      </section>

      {/* Footer */}
      <footer style={lp.footer}>
        <img src="../../assets/ipreneur-logo.webp" alt="iPreneur" style={{ width: 110 }} />
        <span style={lp.footNote}>© 2026 iPreneur · Startup Accelerator</span>
      </footer>
    </div>
  );
}

const lp = {
  nav: { display: "flex", alignItems: "center", justifyContent: "space-between", padding: "18px 44px", borderBottom: "1px solid var(--border-subtle)", background: "rgba(255,255,255,0.8)", backdropFilter: "blur(10px)", position: "sticky", top: 0, zIndex: 20 },
  navLinks: { display: "flex", gap: 28, position: "absolute", left: "50%", transform: "translateX(-50%)" },
  navLink: { font: "500 14px var(--font-body)", color: "var(--text-muted)", textDecoration: "none" },
  signin: { font: "600 14px var(--font-body)", color: "var(--text-body)", textDecoration: "none", padding: "0 12px" },
  hero: { position: "relative", overflow: "hidden", padding: "84px 24px 72px", textAlign: "center" },
  halo: { position: "absolute", inset: 0, background: "var(--grad-hero)", pointerEvents: "none" },
  heroInner: { position: "relative", maxWidth: 820, margin: "0 auto" },
  eyebrowPill: { display: "inline-flex", alignItems: "center", gap: 8, padding: "7px 15px", borderRadius: 99, background: "var(--surface-card)", border: "1px solid var(--violet-200)", boxShadow: "var(--shadow-xs)", font: "500 13px var(--font-body)", color: "var(--text-body)", marginBottom: 26 },
  h1: { font: "800 60px var(--font-display)", lineHeight: 1.04, letterSpacing: "-0.035em", color: "var(--text-strong)" },
  lead: { maxWidth: 600, margin: "22px auto 0", font: "400 18px var(--font-body)", lineHeight: 1.55, color: "var(--text-muted)" },
  heroCtas: { display: "flex", gap: 12, justifyContent: "center", marginTop: 32 },
  heroTrust: { display: "flex", alignItems: "center", justifyContent: "center", gap: 16, marginTop: 30, font: "400 13px var(--font-body)", color: "var(--text-muted)" },
  trustDivider: { width: 4, height: 4, borderRadius: 99, background: "var(--border-strong)" },
  logosWrap: { textAlign: "center", padding: "8px 24px 56px" },
  logosLabel: { font: "500 12px var(--font-body)", letterSpacing: "0.04em", textTransform: "uppercase", color: "var(--text-faint)" },
  logos: { display: "flex", flexWrap: "wrap", justifyContent: "center", gap: 38, marginTop: 22 },
  logo: { font: "700 22px var(--font-display)", letterSpacing: "-0.02em", color: "var(--neutral-400)" },
  section: { maxWidth: 1080, margin: "0 auto", padding: "64px 24px" },
  sectionHead: { textAlign: "center", marginBottom: 40 },
  h2: { font: "800 38px var(--font-display)", letterSpacing: "-0.03em", color: "var(--text-strong)", marginTop: 10 },
  featGrid: { display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 18 },
  feat: { padding: 28 },
  featIcon: { display: "inline-flex", alignItems: "center", justifyContent: "center", width: 46, height: 46, borderRadius: "var(--radius-md)", background: "var(--violet-100)", color: "var(--violet-600)", marginBottom: 18 },
  featTitle: { font: "700 19px var(--font-display)", color: "var(--text-strong)", marginBottom: 9 },
  featDesc: { font: "400 14px var(--font-body)", lineHeight: 1.6, color: "var(--text-muted)" },
  howCard: { position: "relative", overflow: "hidden", borderRadius: "var(--radius-2xl)", background: "var(--grad-brand-vivid)", padding: "52px 48px", boxShadow: "var(--glow-brand)" },
  howHead: { textAlign: "center", marginBottom: 40 },
  steps: { display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 28 },
  step: { background: "rgba(255,255,255,0.12)", border: "1px solid rgba(255,255,255,0.18)", borderRadius: "var(--radius-lg)", padding: 24, backdropFilter: "blur(4px)" },
  stepNum: { font: "700 13px var(--font-mono)", color: "rgba(255,255,255,0.7)" },
  stepTitle: { font: "700 19px var(--font-display)", color: "#fff", margin: "12px 0 8px" },
  stepDesc: { font: "400 14px var(--font-body)", lineHeight: 1.6, color: "rgba(255,255,255,0.88)" },
  ctaBand: { textAlign: "center", padding: "72px 24px 80px", maxWidth: 680, margin: "0 auto" },
  ctaH: { font: "800 40px var(--font-display)", letterSpacing: "-0.03em", color: "var(--text-strong)" },
  ctaSub: { margin: "16px auto 30px", font: "400 17px var(--font-body)", color: "var(--text-muted)" },
  footer: { display: "flex", alignItems: "center", justifyContent: "space-between", padding: "28px 44px", borderTop: "1px solid var(--border-subtle)" },
  footNote: { font: "400 13px var(--font-body)", color: "var(--text-faint)" },
};

window.Landing = Landing;
ReactDOM.createRoot(document.getElementById("root")).render(<Landing />);
